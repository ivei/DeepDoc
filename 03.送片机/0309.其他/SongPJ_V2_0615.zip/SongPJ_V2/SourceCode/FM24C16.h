#ifndef __FM24C16_H_
#define __FM24C16_H_

#define FM24_DEVICE_C04
//#define FM24_DEVICE_C16

#define MAXADDRESS_04 	512
#define MAXADDRESS_16 	2048

extern uint8_t FM24_I2CAddressAdapt(uint16_t framAddr); 
extern uint8_t FM24_Write_Buf(uint16_t framAddr, uint8_t* pBuf, uint16_t Len); 
extern uint8_t FM24_Read_Buf(uint16_t framAddr, uint8_t* pBuf, uint16_t Len); 

#endif
