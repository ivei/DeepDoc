#include "main.h"
#include "gpio.h"
#include "common.h"
#include "StepMotor.h"
#include "device_driver.h"
#include "sys_isr.h"
#include "StepMotor.h"
#include "SCI.h"
#include "FM24C16.h"
#include "qp_move_ctrl.h"


//static unsigned int z_step_status  = 0;

static uint8_t sys_step            = 0;

CUR_SPJ_STATUS_t                     CUR_SPJ_STATUS;

int ZBP_ZB[ZaiBoPian_MAX][4] =  //�ز�Ƭ����
{
//     x            y     dst_offset(�ز�̨ȡƬ����) y jia _offset(��Ƭ�ܷ�Ƭ����)(��=DOWN, ��=UP)
//	AA��������
    {AA_X,	        AA_Y,			    1200,       -1800}, // 0 //30000    -2060
    {AA_X,	        AA_Y+1*DELTA_Y,		1200,       -1800}, // 1 
    {AA_X,	        AA_Y+2*DELTA_Y,	    1200,       -1800}, // 2 
    {AA_X,	        AA_Y+3*DELTA_Y,	    1200,       -1800}, // 3 
    {AA_X,	        AA_Y+4*DELTA_Y,	    1200,       -1800}, // 4 
    {AA_X,	        AA_Y+5*DELTA_Y,	    1200,       -1800}, // 5 
    {AA_X,	        AA_Y+6*DELTA_Y,	    1200,       -1800}, // 6 
    {AA_X,	        AA_Y+7*DELTA_Y,	    1200,       -1800}, // 7 
    {AA_X,	        AA_Y+8*DELTA_Y,	    1200,       -1800}, // 8 
    {AA_X,	        AA_Y+9*DELTA_Y,	    1200,       -1800}, // 9 
    {AA_X,	        AA_Y+10*DELTA_Y,	1200,       -1800}, // 10 
    {AA_X,	        AA_Y+11*DELTA_Y,	1200,       -1800}, // 11 
    {AA_X,	        AA_Y+12*DELTA_Y,	1200,       -1800}, // 12 
    {AA_X,	        AA_Y+13*DELTA_Y,	1200,       -1800}, // 13 
    {AA_X,	        AA_Y+14*DELTA_Y,	1200,       -1800}, // 14 
    
    {AA_X,	        AA_YB,			    1200,       -1800}, // 15 //30000    -2060
    {AA_X,	        AA_YB+1*DELTA_Y,	1200,       -1800}, // 16 
    {AA_X,	        AA_YB+2*DELTA_Y,	1200,       -1800}, // 17 
    {AA_X,	        AA_YB+3*DELTA_Y,	1200,       -1800}, // 18 
    {AA_X,	        AA_YB+4*DELTA_Y,	1200,       -1800}, // 19 
    {AA_X,	        AA_YB+5*DELTA_Y,	1200,       -1800}, // 20 
    {AA_X,	        AA_YB+6*DELTA_Y,	1200,       -1800}, // 21 
    {AA_X,	        AA_YB+7*DELTA_Y,	1200,       -1800}, // 22 
    {AA_X,	        AA_YB+8*DELTA_Y,	1200,       -1800}, // 23 
    {AA_X,	        AA_YB+9*DELTA_Y,	1200,       -1800}, // 24 
    {AA_X,	        AA_YB+10*DELTA_Y,	1200,       -1800}, // 25 
    {AA_X,	        AA_YB+11*DELTA_Y,	1200,       -1800}, // 26 
    {AA_X,	        AA_YB+12*DELTA_Y,	1200,       -1800}, // 27 
    {AA_X,	        AA_YB+13*DELTA_Y,	1200,       -1800}, // 28 
    {AA_X,	        AA_YB+14*DELTA_Y,	1200,       -1800}, // 29    
    
    
//	AB��������
    {AA_X-AAAB_X,	AA_Y,				1200,       -1800}, // 30 //30000    -2060
    {AA_X-AAAB_X,	AA_Y+1*DELTA_Y,		1200,       -1800}, // 31 
    {AA_X-AAAB_X,	AA_Y+2*DELTA_Y,	    1200,       -1800}, // 32 
    {AA_X-AAAB_X,	AA_Y+3*DELTA_Y,	    1200,       -1800}, // 33 
    {AA_X-AAAB_X,	AA_Y+4*DELTA_Y,	    1200,       -1800}, // 34 
    {AA_X-AAAB_X,	AA_Y+5*DELTA_Y,	    1200,       -1800}, // 35 
    {AA_X-AAAB_X,	AA_Y+6*DELTA_Y,	    1200,       -1800}, // 36 
    {AA_X-AAAB_X,	AA_Y+7*DELTA_Y,	    1200,       -1800}, // 37 
    {AA_X-AAAB_X,	AA_Y+8*DELTA_Y,	    1200,       -1800}, // 38 
    {AA_X-AAAB_X,	AA_Y+9*DELTA_Y,	    1200,       -1800}, // 39 
    {AA_X-AAAB_X,	AA_Y+10*DELTA_Y,	1200,       -1800}, // 40 
    {AA_X-AAAB_X,	AA_Y+11*DELTA_Y,	1200,       -1800}, // 41 
    {AA_X-AAAB_X,	AA_Y+12*DELTA_Y,	1200,       -1800}, // 42 
    {AA_X-AAAB_X,	AA_Y+13*DELTA_Y,	1200,       -1800}, // 43 
    {AA_X-AAAB_X,	AA_Y+14*DELTA_Y,	1200,       -1800}, // 44 
    
    {AA_X-AAAB_X,	AA_YB,				1200,       -1800}, // 45 //30000    -2060
    {AA_X-AAAB_X,	AA_YB+1*DELTA_Y,	1200,       -1800}, // 46 
    {AA_X-AAAB_X,	AA_YB+2*DELTA_Y,	1200,       -1800}, // 47 
    {AA_X-AAAB_X,	AA_YB+3*DELTA_Y,	1200,       -1800}, // 48 
    {AA_X-AAAB_X,	AA_YB+4*DELTA_Y,	1200,       -1800}, // 49 
    {AA_X-AAAB_X,	AA_YB+5*DELTA_Y,	1200,       -1800}, // 50 
    {AA_X-AAAB_X,	AA_YB+6*DELTA_Y,	1200,       -1800}, // 51 
    {AA_X-AAAB_X,	AA_YB+7*DELTA_Y,	1200,       -1800}, // 52 
    {AA_X-AAAB_X,	AA_YB+8*DELTA_Y,	1200,       -1800}, // 53 
    {AA_X-AAAB_X,	AA_YB+9*DELTA_Y,	1200,       -1800}, // 54 
    {AA_X-AAAB_X,	AA_YB+10*DELTA_Y,	1200,       -1800}, // 55 
    {AA_X-AAAB_X,	AA_YB+11*DELTA_Y,	1200,       -1800}, // 56 
    {AA_X-AAAB_X,	AA_YB+12*DELTA_Y,	1200,       -1800}, // 57 
    {AA_X-AAAB_X,	AA_YB+13*DELTA_Y,	1200,       -1800}, // 58 
    {AA_X-AAAB_X,	AA_YB+14*DELTA_Y,	1200,       -1800}, // 59     
    
    
//	BA��������
	{AA_X-AABA_X,	AA_Y,				1200,       -1800}, // 60 //30000    -2060
    {AA_X-AABA_X,	AA_Y+1*DELTA_Y,		1200,       -1800}, // 61 
    {AA_X-AABA_X,	AA_Y+2*DELTA_Y,	    1200,       -1800}, // 62 
    {AA_X-AABA_X,	AA_Y+3*DELTA_Y,	    1200,       -1800}, // 63 
    {AA_X-AABA_X,	AA_Y+4*DELTA_Y,	    1200,       -1800}, // 64 
    {AA_X-AABA_X,	AA_Y+5*DELTA_Y,	    1200,       -1800}, // 65 
    {AA_X-AABA_X,	AA_Y+6*DELTA_Y,	    1200,       -1800}, // 66 
    {AA_X-AABA_X,	AA_Y+7*DELTA_Y,	    1200,       -1800}, // 67 
    {AA_X-AABA_X,	AA_Y+8*DELTA_Y,	    1200,       -1800}, // 68 
    {AA_X-AABA_X,	AA_Y+9*DELTA_Y,	    1200,       -1800}, // 69 
    {AA_X-AABA_X,	AA_Y+10*DELTA_Y,	1200,       -1800}, // 70 
    {AA_X-AABA_X,	AA_Y+11*DELTA_Y,	1200,       -1800}, // 71 
    {AA_X-AABA_X,	AA_Y+12*DELTA_Y,	1200,       -1800}, // 72 
    {AA_X-AABA_X,	AA_Y+13*DELTA_Y,	1200,       -1800}, // 73 
    {AA_X-AABA_X,	AA_Y+14*DELTA_Y,	1200,       -1800}, // 74 

	{AA_X-AABA_X,	AA_YB,				1200,       -1800}, // 75 //30000    -2060
    {AA_X-AABA_X,	AA_YB+1*DELTA_Y,	1200,       -1800}, // 76 
    {AA_X-AABA_X,	AA_YB+2*DELTA_Y,	1200,       -1800}, // 77 
    {AA_X-AABA_X,	AA_YB+3*DELTA_Y,	1200,       -1800}, // 78 
    {AA_X-AABA_X,	AA_YB+4*DELTA_Y,	1200,       -1800}, // 79 
    {AA_X-AABA_X,	AA_YB+5*DELTA_Y,	1200,       -1800}, // 80 
    {AA_X-AABA_X,	AA_YB+6*DELTA_Y,	1200,       -1800}, // 81 
    {AA_X-AABA_X,	AA_YB+7*DELTA_Y,	1200,       -1800}, // 82 
    {AA_X-AABA_X,	AA_YB+8*DELTA_Y,	1200,       -1800}, // 83 
    {AA_X-AABA_X,	AA_YB+9*DELTA_Y,	1200,       -1800}, // 84 
    {AA_X-AABA_X,	AA_YB+10*DELTA_Y,	1200,       -1800}, // 85 
    {AA_X-AABA_X,	AA_YB+11*DELTA_Y,	1200,       -1800}, // 86 
    {AA_X-AABA_X,	AA_YB+12*DELTA_Y,	1200,       -1800}, // 87 
    {AA_X-AABA_X,	AA_YB+13*DELTA_Y,	1200,       -1800}, // 88 
    {AA_X-AABA_X,	AA_YB+14*DELTA_Y,	1200,       -1800}, // 89     
    
    
//	BB��������
    {AA_X-AABB_X,	AA_Y,				1200,       -1800}, // 90 //30000    -2060
    {AA_X-AABB_X,	AA_Y+1*DELTA_Y,		1200,       -1800}, // 91 
    {AA_X-AABB_X,	AA_Y+2*DELTA_Y,	    1200,       -1800}, // 92 
    {AA_X-AABB_X,	AA_Y+3*DELTA_Y,	    1200,       -1800}, // 93 
    {AA_X-AABB_X,	AA_Y+4*DELTA_Y,	    1200,       -1800}, // 94 
    {AA_X-AABB_X,	AA_Y+5*DELTA_Y,	    1200,       -1800}, // 95 
    {AA_X-AABB_X,	AA_Y+6*DELTA_Y,	    1200,       -1800}, // 96 
    {AA_X-AABB_X,	AA_Y+7*DELTA_Y,	    1200,       -1800}, // 97 
    {AA_X-AABB_X,	AA_Y+8*DELTA_Y,	    1200,       -1800}, // 98 
    {AA_X-AABB_X,	AA_Y+9*DELTA_Y,	    1200,       -1800}, // 99 
    {AA_X-AABB_X,	AA_Y+10*DELTA_Y,	1200,       -1800}, // 100 
    {AA_X-AABB_X,	AA_Y+11*DELTA_Y,	1200,       -1800}, // 101 
    {AA_X-AABB_X,	AA_Y+12*DELTA_Y,	1200,       -1800}, // 102 
    {AA_X-AABB_X,	AA_Y+13*DELTA_Y,	1200,       -1800}, // 103 
    {AA_X-AABB_X,	AA_Y+14*DELTA_Y,	1200,       -1800}, // 104 
    
    {AA_X-AABB_X,	AA_YB,				1200,       -1800}, // 105 //30000    -2060
    {AA_X-AABB_X,	AA_YB+1*DELTA_Y,	1200,       -1800}, // 106 
    {AA_X-AABB_X,	AA_YB+2*DELTA_Y,	1200,       -1800}, // 107 
    {AA_X-AABB_X,	AA_YB+3*DELTA_Y,	1200,       -1800}, // 108 
    {AA_X-AABB_X,	AA_YB+4*DELTA_Y,	1200,       -1800}, // 109 
    {AA_X-AABB_X,	AA_YB+5*DELTA_Y,	1200,       -1800}, // 110
    {AA_X-AABB_X,	AA_YB+6*DELTA_Y,	1200,       -1800}, // 111
    {AA_X-AABB_X,	AA_YB+7*DELTA_Y,	1200,       -1800}, // 112 
    {AA_X-AABB_X,	AA_YB+8*DELTA_Y,	1200,       -1800}, // 113 
    {AA_X-AABB_X,	AA_YB+9*DELTA_Y,	1200,       -1800}, // 114 
    {AA_X-AABB_X,	AA_YB+10*DELTA_Y,	1200,       -1800}, // 115
    {AA_X-AABB_X,	AA_YB+11*DELTA_Y,	1200,       -1800}, // 116 
    {AA_X-AABB_X,	AA_YB+12*DELTA_Y,	1200,       -1800}, // 117 
    {AA_X-AABB_X,	AA_YB+13*DELTA_Y,	1200,       -1800}, // 118 
    {AA_X-AABB_X,	AA_YB+14*DELTA_Y,	1200,       -1800}, // 119 
    
};

void DJ_CTRL(DJ_STATUS STAT)
{
    //SEG04_EN_On();
    switch(STAT)
    {
        case DJ_OPEN:
            SEG04_DIR_Off();
            break;
        case DJ_CLOSE:
            SEG04_DIR_On();
            break;
        default:
            break;   
    }
}

extern uint8_t     SPJ_BP_STATUS;

uint8_t zbp_move_select(signed short cnt) //ȡƬ�ͻ�Ƭ
{
    uint8_t ret                 = 0;
    static  uint8_t last_cnt    = 0;
    static  uint8_t zbp_get_rtn_flag    = 0; //�Ѿ���ʼȡƬ���߻�Ƭ��־
    uint32_t t_start    = 0; 
    uint32_t t_stop     = 0;   
    
    if ( (cnt > ZaiBoPian_MAX-1) || (cnt < 0) )
        return 0;
    
    if (CUR_SPJ_STATUS.zbp_run_flag == 0)
    {
        last_cnt                    = cnt;
        CUR_SPJ_STATUS.zbp_run_flag = 1;
    }
    else
    {        
        if (CUR_SPJ_STATUS.zbp_rtn_any_flag == 1)
        {
            CUR_SPJ_STATUS.zbp_rtn_any_flag = 0;
            last_cnt                = cnt;
        }            
        else
        {
            cnt = last_cnt;
        }
    }
    
    if ( (zbp_get_rtn_flag == 0) && (CUR_SPJ_STATUS.zbp_get_flag == 1) ) //����ȡƬ
    {
        zbp_get_rtn_flag    = 1;
        sys_step            = 1;
        SPJ_BP_STATUS = FAIL_GET_ING;
//        FM24_Write_Buf(0x00, &SPJ_BP_STATUS, 1);
    }
    
    if ( (zbp_get_rtn_flag == 0) && (CUR_SPJ_STATUS.zbp_rtn_flag == 1) ) //���ڻ�Ƭ
    {
        zbp_get_rtn_flag    = 1;
        sys_step            = 9;
        SPJ_BP_STATUS = FAIL_RTN_ING;
//        FM24_Write_Buf(0x00, &SPJ_BP_STATUS, 1);
    }   
    
    if (CUR_SPJ_STATUS.zbp_get_flag == 1)
    {
        switch (sys_step)
        {
            case 1: //x,y,z 
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    printf("Get glass %d.\r\n", cnt);
                    CUR_SPJ_STATUS.x_step      = ZBP_ZB[cnt][0] - CUR_SPJ_STATUS.total_x_step; //x_step = 30200;
                    CUR_SPJ_STATUS.y_step      = ZBP_ZB[cnt][1] - CUR_SPJ_STATUS.total_y_step; //y_step = 30700;
                    CUR_SPJ_STATUS.z_step      = temp_z_temp    - CUR_SPJ_STATUS.total_z_step;
                    sys_step    = 2;
                }
                break;
            case 2: //z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    delayms(500);
                    CUR_SPJ_STATUS.z_step   = temp_z_get - CUR_SPJ_STATUS.total_z_step;
                    sys_step                = 3;
                }
                break;
            case 3: //�����
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    DJ_CTRL(DJ_CLOSE);
                    delayms(500);
                    sys_step    = 4;
                }
                break;
            case 4: //z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.z_step   = - CUR_SPJ_STATUS.total_z_step;
                    sys_step                = 5;
                }
                break;
            case 5: //x,y
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {                    
                    if (LimPosi[AXIS_Z] == FALSE) // ǿ�Ƹ�λZ�ᵽԭ��
                    {
                        STEPMOTOR_DIR_REVERSAL(AXIS_Z);
                        t_start = SysTick_GetTimeOfMs();
                        do
                        {       
                            M3_CLK_Toggle();
                            delayus(650);
                            t_stop = SysTick_GetTimeOfMs();
                            if(t_stop - t_start > 5000)
                                break;
                        }while(LimPosi[AXIS_Z] == FALSE);
                    }
                    //���ز�̨��Ƭ������
                    CUR_SPJ_STATUS.x_step   = dst_zb_x - ZBP_ZB[cnt][0]; // x_step      = -26500;
                    CUR_SPJ_STATUS.y_step   = dst_zb_y - ZBP_ZB[cnt][1]; // y_step      = 53100;
                    sys_step                = 6;
                }
                break;
            case 6: //z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.z_step   = temp_z_dst - CUR_SPJ_STATUS.total_z_step;
                    sys_step                = 7;
                }                
                break;
            case 7: //���kai
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    DJ_CTRL(DJ_OPEN);
                    delayms(500);
                    sys_step    = 8;
                }
                break;              
            case 8: //z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.z_step       = temp_z_temp - CUR_SPJ_STATUS.total_z_step;
                    CUR_SPJ_STATUS.zbp_get_flag = 0;
                    CUR_SPJ_STATUS.zbp_in_get_flag = 1;
                    SPJ_BP_STATUS = FAIL_ZBT_ON;
//                    FM24_Write_Buf(0x00, &SPJ_BP_STATUS, 1);
                    zbp_get_rtn_flag            = 0;
                    sys_step                    = 8;        // stop here
                }                
                break;
            default:
                break;
        }
    }
    
    if (CUR_SPJ_STATUS.zbp_rtn_flag == 1)
    {
        switch (sys_step)
        {              
            case 9: //y,z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    printf("Return glass %d.\r\n", cnt);
                    CUR_SPJ_STATUS.x_step       = RTN_GET_OFFSET; // ����ƫ�ƣ��¼�
                    CUR_SPJ_STATUS.y_step       = ZBP_ZB[cnt][2]; // ����ѹ
                    CUR_SPJ_STATUS.z_step       = temp_z_dst - CUR_SPJ_STATUS.total_z_step;
                    sys_step                    = 10; 
                }  
                break;
            case 10: //�����
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    DJ_CTRL(DJ_CLOSE);
                    delayms(500);
                    sys_step    = 11; 
                }                
                break;
            case 11: //z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.z_step       = - CUR_SPJ_STATUS.total_z_step;
                    sys_step                    = 12;
                }
                break;
            case 12: //x,y
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.x_step = ZBP_ZB[cnt][0] - CUR_SPJ_STATUS.total_x_step;
                    CUR_SPJ_STATUS.y_step = ZBP_ZB[cnt][1] - CUR_SPJ_STATUS.total_y_step + ZBP_ZB[cnt][3]; // ����̧
									
										//CUR_SPJ_STATUS.x_step = ZBP_ZB[cnt][0] - dst_zb_x - RTN_GET_OFFSET;
                    //CUR_SPJ_STATUS.y_step = ZBP_ZB[cnt][1] - dst_zb_y + ZBP_ZB[cnt][3]; // ����̧
                    sys_step = 13; 
                }                
                break;
            case 13: //z
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.z_step      = temp_z_get - CUR_SPJ_STATUS.total_z_step;
                    sys_step    = 14;
                }
                break;
            case 14: //���kai
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    DJ_CTRL(DJ_OPEN);
                    delayms(500);
                    sys_step    = 15; 
                }                
                break;
            case 15:
                if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
                {
                    CUR_SPJ_STATUS.zbp_run_flag     = 0;
                    
                    CUR_SPJ_STATUS.zbp_rtn_flag     = 0;
                    zbp_get_rtn_flag                = 0;
                    CUR_SPJ_STATUS.ROTOR_SELECT_CNT = 0;
                    CUR_SPJ_STATUS.zbp_in_get_flag  = 0;
                    SPJ_BP_STATUS = FAIL_NONE;
//                    FM24_Write_Buf(0x00, &SPJ_BP_STATUS, 1);
                    CUR_SPJ_STATUS.z_step           = temp_z_temp - CUR_SPJ_STATUS.total_z_step;
                    ret = 1;
                    sys_step = 15; //stop here
                }
                break;
            default:
                break;
        }
    }    
    
    return ret;
}

#define     MAX_X_STEPS     34200
#define     MAX_Y_STEPS     140000
#define     MAX_Z_STEPS     37800

void moto_move(void)
{ 
//-X---------------------------------------------------------------  // max step 34200  
    if ( (MotionStatus[AXIS_X] == STOP) && (CUR_SPJ_STATUS.x_step != 0) && (CUR_SPJ_STATUS.x_step+CUR_SPJ_STATUS.total_x_step<=MAX_X_STEPS) && (CUR_SPJ_STATUS.x_step+CUR_SPJ_STATUS.total_x_step>=0) )
    {
        STEPMOTOR_AxisMoveRel(AXIS_X, CUR_SPJ_STATUS.x_step, 8000, 8000, 300);//step_accel, step_decel, set_speed//8000, 8000, 250
		step_position[0] = CUR_SPJ_STATUS.total_x_step;
        CUR_SPJ_STATUS.total_x_step += CUR_SPJ_STATUS.x_step;
        CUR_SPJ_STATUS.x_step = 0;
    }
    else
    {
        CUR_SPJ_STATUS.x_step = 0;
    }
//-Y---------------------------------------------------------------  //max step 140000    
    if ( (MotionStatus[AXIS_Y] == STOP) && (CUR_SPJ_STATUS.y_step != 0) && (CUR_SPJ_STATUS.y_step+CUR_SPJ_STATUS.total_y_step<=MAX_Y_STEPS) && (CUR_SPJ_STATUS.y_step+CUR_SPJ_STATUS.total_y_step>=0) )
    {
        STEPMOTOR_AxisMoveRel(AXIS_Y, CUR_SPJ_STATUS.y_step, 8000, 8000, 600);//8000, 8000, 400
		step_position[1] = CUR_SPJ_STATUS.total_y_step;
        CUR_SPJ_STATUS.total_y_step += CUR_SPJ_STATUS.y_step;      
        CUR_SPJ_STATUS.y_step = 0;
    }
    else
    {
        CUR_SPJ_STATUS.y_step = 0;
    }
//-Z---------------------------------------------------------------    //max step 37800 
    if ( (MotionStatus[AXIS_Z] == STOP) && (CUR_SPJ_STATUS.z_step != 0) && (CUR_SPJ_STATUS.z_step+CUR_SPJ_STATUS.total_z_step<=MAX_Z_STEPS) && (CUR_SPJ_STATUS.z_step+CUR_SPJ_STATUS.total_z_step>=0) )
    {
        STEPMOTOR_AxisMoveRel(AXIS_Z, CUR_SPJ_STATUS.z_step, 8000, 8000, 300);//8000, 8000, 300
		step_position[2] = CUR_SPJ_STATUS.total_z_step;
        CUR_SPJ_STATUS.total_z_step += CUR_SPJ_STATUS.z_step;      
        CUR_SPJ_STATUS.z_step = 0;
    }
    else
    {
        CUR_SPJ_STATUS.z_step = 0;
    }
    //delayms(200);    
}

void All_Moto_Go_Zero(void)
{
    CUR_SPJ_STATUS.x_step = -CUR_SPJ_STATUS.total_x_step;
    CUR_SPJ_STATUS.y_step = -CUR_SPJ_STATUS.total_y_step;
    CUR_SPJ_STATUS.z_step = -CUR_SPJ_STATUS.total_z_step;
    CUR_SPJ_STATUS.MOTO_SYS_STATUS = 1;
    DJ_CTRL(DJ_OPEN);
}
