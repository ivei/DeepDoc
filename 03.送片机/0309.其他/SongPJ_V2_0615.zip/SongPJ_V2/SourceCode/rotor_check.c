#include "main.h"
#include "common.h"
#include "gpio.h"
#include "qp_move_ctrl.h"
#include "SCI.h"
#include "StepMotor.h"
#include "device_driver.h"
#include "rotor_check.h"

Rotor_Info_t        Rotor_Info; //�洢��⵽��Ƭ���ж���Ϣ����������

Rotor_Use_Info_t    Rotor_Info_dip1;
Rotor_Use_Info_t    Rotor_Info_dip2;
Rotor_Use_Info_t    Rotor_Info_dip3;
Rotor_Use_Info_t    Rotor_Info_dip4;

Rotor_Use_Info_t    Rotor_Info_dip1B;
Rotor_Use_Info_t    Rotor_Info_dip2B;
Rotor_Use_Info_t    Rotor_Info_dip3B;
Rotor_Use_Info_t    Rotor_Info_dip4B;

static uint8_t rotor_check_step            = 0;

void HG1050_IRQHandler(void)
{
    if (Rotor_Info.interrupt_num > ROTOR_MAX_CNT - 1)
    {
        Rotor_Info.interrupt_num = ROTOR_MAX_CNT - 1;
    }
    
    HG_C1050_OUT_IN(); 
    
    Rotor_Info.rotor_info_arg[Rotor_Info.interrupt_num][0] = MOTO_Get_Moto_Steps(AXIS_X);
    Rotor_Info.rotor_info_arg[Rotor_Info.interrupt_num][1] = MOTO_Get_Moto_Steps(AXIS_Y);
    Rotor_Info.rotor_info_arg[Rotor_Info.interrupt_num][2] = HG_C1050_OUT_Read();
    
    if (Rotor_Info.interrupt_num > 0)
        Rotor_Info.rotor_info_arg[Rotor_Info.interrupt_num][3] = Rotor_Info.rotor_info_arg[Rotor_Info.interrupt_num][1] - \
                                                                 Rotor_Info.rotor_info_arg[Rotor_Info.interrupt_num - 1][1];
    
    Rotor_Info.interrupt_num++;
}

int32_t CHECK_POS_INFO[CHECK_MAX_DIP][3];

uint8_t  CURRENT_DIP_COUNTER = 0;//��¼��ǰɨ������

uint8_t Check_Rotor_Start(void)
{
    uint8_t ret = 0;
    uint8_t i = 0;
    
    if (CUR_SPJ_STATUS.rotor_check_flag == 0)
    {
        rotor_check_step = 1;
        VM_PWR_CTRL_On();       //HG1050 Power En
        
        delayms(100);
    }
    else
    {
        
    }
    
    switch (rotor_check_step)
    {
        case 1: //x,y,z  //DIP1
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {   
                CUR_SPJ_STATUS.x_step              = CHECK_DIP1_X - CUR_SPJ_STATUS.total_x_step;    
                CUR_SPJ_STATUS.y_step              = CHECK_DIP1_Y - CUR_SPJ_STATUS.total_y_step;    
                CUR_SPJ_STATUS.z_step            = CHECK_DIP1_Z - CUR_SPJ_STATUS.total_z_step;
                CUR_SPJ_STATUS.rotor_check_flag    = 1;
                rotor_check_step    = 2;
            }
            break;
        case 2: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                Rotor_Info.interrupt_num = 0;
                FTM0_Enable_Interrupt();          
                CUR_SPJ_STATUS.y_step              = CHECK_Y_END_STEP - CUR_SPJ_STATUS.total_y_step;
                rotor_check_step    = 3;
            }
            break;
        case 3: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {   
                FTM0_Disable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_DIP1_Y - CUR_SPJ_STATUS.total_y_step;
                rotor_check_step    = 4;
            }
            break;
        case 4: //dip 2
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                CUR_SPJ_STATUS.x_step              = CHECK_DIP2_X - CUR_SPJ_STATUS.total_x_step;    //x_step = 30200;
                CUR_SPJ_STATUS.y_step              = CHECK_DIP2_Y - CUR_SPJ_STATUS.total_y_step;    //y_step = 30700;
                CUR_SPJ_STATUS.z_step            = CHECK_DIP2_Z - CUR_SPJ_STATUS.total_z_step;;
                rotor_check_step    = 5;
            }
            break;
        case 5: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Enable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_Y_END_STEP - CUR_SPJ_STATUS.total_y_step;;
                rotor_check_step    = 6;
            }
            break;
        case 6: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Disable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_DIP2_Y - CUR_SPJ_STATUS.total_y_step;;
                rotor_check_step    = 7;
            }                
            break;
        case 7: //dip 3
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                CUR_SPJ_STATUS.x_step              = CHECK_DIP3_X - CUR_SPJ_STATUS.total_x_step;    //x_step = 30200;
                CUR_SPJ_STATUS.y_step              = CHECK_DIP3_Y - CUR_SPJ_STATUS.total_y_step;    //y_step = 30700;
                CUR_SPJ_STATUS.z_step            = CHECK_DIP3_Z - CUR_SPJ_STATUS.total_z_step;;
                rotor_check_step    = 8;
            }
            break;
        case 8: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Enable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_Y_END_STEP - CUR_SPJ_STATUS.total_y_step;;
                rotor_check_step    = 9;
            }
            break;
        case 9: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Disable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_DIP3_Y - CUR_SPJ_STATUS.total_y_step;;
                rotor_check_step    = 10;
            }                
            break;            
            
        case 10: //dip 4
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                CUR_SPJ_STATUS.x_step              = CHECK_DIP4_X - CUR_SPJ_STATUS.total_x_step;    //x_step = 30200;
                CUR_SPJ_STATUS.y_step              = CHECK_DIP4_Y - CUR_SPJ_STATUS.total_y_step;    //y_step = 30700;
                CUR_SPJ_STATUS.z_step            = CHECK_DIP4_Z - CUR_SPJ_STATUS.total_z_step;;
                rotor_check_step    = 11;
            }
            break;
        case 11: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Enable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_Y_END_STEP - CUR_SPJ_STATUS.total_y_step;;
                rotor_check_step    = 12;
            }
            break;
        case 12: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Disable_Interrupt();
                CUR_SPJ_STATUS.y_step              = CHECK_DIP4_Y - CUR_SPJ_STATUS.total_y_step;;
                rotor_check_step    = 13;
            }                
            break;                   
        case 13: //gui 0
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Disable_Interrupt();
                rotor_data_handle(&Rotor_Info);
                CUR_SPJ_STATUS.x_step = -CUR_SPJ_STATUS.total_x_step;
                CUR_SPJ_STATUS.y_step = -CUR_SPJ_STATUS.total_y_step;
                CUR_SPJ_STATUS.z_step = -CUR_SPJ_STATUS.total_z_step;
                ret = 1;
                rotor_check_step    = 14;      //stop          
                CUR_SPJ_STATUS.rotor_check_flag    = 0;
                VM_PWR_CTRL_Off();                       //HG1050 Power off
            }
            break;              
        default:
            break;
    }
    
    return ret;
}

int abs_int(int value)
{
    if (value<0)
        return (-value);

    return value;
}

uint16_t rotor_data_handle(Rotor_Info_t *pInfo)
{
    int i;
    uint8_t temp;
    
    Rotor_Info_dip1.interrupt_num = 0;
    Rotor_Info_dip1.ROTER_STATUS = 0;
    Rotor_Info_dip2.interrupt_num = 0;
    Rotor_Info_dip2.ROTER_STATUS = 0;
    Rotor_Info_dip3.interrupt_num = 0;
    Rotor_Info_dip3.ROTER_STATUS = 0;
    Rotor_Info_dip4.interrupt_num = 0;
    Rotor_Info_dip4.ROTER_STATUS = 0;
    
    Rotor_Info_dip1B.interrupt_num = 0;
    Rotor_Info_dip1B.ROTER_STATUS = 0;
    Rotor_Info_dip2B.interrupt_num = 0;
    Rotor_Info_dip2B.ROTER_STATUS = 0;
    Rotor_Info_dip3B.interrupt_num = 0;
    Rotor_Info_dip3B.ROTER_STATUS = 0;
    Rotor_Info_dip4B.interrupt_num = 0;
    Rotor_Info_dip4B.ROTER_STATUS = 0;
    
	printf ("printf total interrupt %d.\r\n", pInfo->interrupt_num);
		
    for (i = 0; i < pInfo->interrupt_num; i++)
    {
        if ( abs_int(pInfo->rotor_info_arg[i][0]- CHECK_DIP1_X) < 50 ) //if (pInfo->rotor_info_arg[i][0] == CHECK_DIP1_X) 
        {
            if ( (pInfo->rotor_info_arg[i][1] >= top_th) && (pInfo->rotor_info_arg[i][1] <= bot_th) && (pInfo->rotor_info_arg[i][2] == 0))
            {     
                if (Rotor_Info_dip1.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip1.interrupt_num = ROTOR_MAX_USE_CNT-1;
                                
                Rotor_Info_dip1.rotor_info_arg[Rotor_Info_dip1.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip1.rotor_info_arg[Rotor_Info_dip1.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip1.rotor_info_arg[Rotor_Info_dip1.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip1.interrupt_num++;
            }
            
            if ( (pInfo->rotor_info_arg[i][1] >= top_th_b) && (pInfo->rotor_info_arg[i][1] <= bot_th_b) && (pInfo->rotor_info_arg[i][2] == 0))
            {     
                if (Rotor_Info_dip1B.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip1B.interrupt_num = ROTOR_MAX_USE_CNT-1;
                                
                Rotor_Info_dip1B.rotor_info_arg[Rotor_Info_dip1B.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip1B.rotor_info_arg[Rotor_Info_dip1B.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip1B.rotor_info_arg[Rotor_Info_dip1B.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip1B.interrupt_num++;
            }
        }
        else if ( abs_int(pInfo->rotor_info_arg[i][0]- CHECK_DIP2_X) < 50 )//else if (pInfo->rotor_info_arg[i][0] == CHECK_DIP2_X)
        {
            if ( (pInfo->rotor_info_arg[i][1] >= top_th) && (pInfo->rotor_info_arg[i][1] <= bot_th) && (pInfo->rotor_info_arg[i][2] == 0))
            {
                if (Rotor_Info_dip2.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip2.interrupt_num = ROTOR_MAX_USE_CNT-1;
                Rotor_Info_dip2.rotor_info_arg[Rotor_Info_dip2.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip2.rotor_info_arg[Rotor_Info_dip2.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip2.rotor_info_arg[Rotor_Info_dip2.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip2.interrupt_num++;
            }
            
            if ( (pInfo->rotor_info_arg[i][1] >= top_th_b) && (pInfo->rotor_info_arg[i][1] <= bot_th_b) && (pInfo->rotor_info_arg[i][2] == 0))
            {
                if (Rotor_Info_dip2B.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip2B.interrupt_num = ROTOR_MAX_USE_CNT-1;
                Rotor_Info_dip2B.rotor_info_arg[Rotor_Info_dip2B.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip2B.rotor_info_arg[Rotor_Info_dip2B.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip2B.rotor_info_arg[Rotor_Info_dip2B.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip2B.interrupt_num++;
            }
        }
        else if ( abs_int(pInfo->rotor_info_arg[i][0]- CHECK_DIP3_X) < 50 ) //else if (pInfo->rotor_info_arg[i][0] == CHECK_DIP3_X)
        {
            if ( (pInfo->rotor_info_arg[i][1] >= top_th) && (pInfo->rotor_info_arg[i][1] <= bot_th) && (pInfo->rotor_info_arg[i][2] == 0))
            {
                if (Rotor_Info_dip3.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip3.interrupt_num = ROTOR_MAX_USE_CNT-1;
                Rotor_Info_dip3.rotor_info_arg[Rotor_Info_dip3.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip3.rotor_info_arg[Rotor_Info_dip3.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip3.rotor_info_arg[Rotor_Info_dip3.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip3.interrupt_num++;
            }
            
            if ( (pInfo->rotor_info_arg[i][1] >= top_th_b) && (pInfo->rotor_info_arg[i][1] <= bot_th_b) && (pInfo->rotor_info_arg[i][2] == 0))
            {
                if (Rotor_Info_dip3B.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip3B.interrupt_num = ROTOR_MAX_USE_CNT-1;
                Rotor_Info_dip3B.rotor_info_arg[Rotor_Info_dip3B.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip3B.rotor_info_arg[Rotor_Info_dip3B.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip3B.rotor_info_arg[Rotor_Info_dip3B.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip3B.interrupt_num++;
            }
        }
        else if ( abs_int(pInfo->rotor_info_arg[i][0]- CHECK_DIP4_X) < 50 ) //else if (pInfo->rotor_info_arg[i][0] == CHECK_DIP4_X)
        {
            if ( (pInfo->rotor_info_arg[i][1] >= top_th) && (pInfo->rotor_info_arg[i][1] <= bot_th) && (pInfo->rotor_info_arg[i][2] == 0))
            {
                if (Rotor_Info_dip4.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip4.interrupt_num = ROTOR_MAX_USE_CNT-1;
                Rotor_Info_dip4.rotor_info_arg[Rotor_Info_dip4.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip4.rotor_info_arg[Rotor_Info_dip4.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip4.rotor_info_arg[Rotor_Info_dip4.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip4.interrupt_num++;
            }
            
            if ( (pInfo->rotor_info_arg[i][1] >= top_th_b) && (pInfo->rotor_info_arg[i][1] <= bot_th_b) && (pInfo->rotor_info_arg[i][2] == 0))
            {
                if (Rotor_Info_dip4B.interrupt_num > ROTOR_MAX_USE_CNT-1)
                    Rotor_Info_dip4B.interrupt_num = ROTOR_MAX_USE_CNT-1;
                Rotor_Info_dip4B.rotor_info_arg[Rotor_Info_dip4B.interrupt_num][0] = pInfo->rotor_info_arg[i][0];
                Rotor_Info_dip4B.rotor_info_arg[Rotor_Info_dip4B.interrupt_num][1] = pInfo->rotor_info_arg[i][1];
                Rotor_Info_dip4B.rotor_info_arg[Rotor_Info_dip4B.interrupt_num][2] = pInfo->rotor_info_arg[i][2];
                
                Rotor_Info_dip4B.interrupt_num++;
            }
        }
    }    
    
    for (i = 0; i<Rotor_Info_dip1.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip1.rotor_info_arg[i][1] - first_th)/rotor2rotor_th);
        Rotor_Info_dip1.ROTER_STATUS |= 1<<temp;
    }   
    for (i = 0; i<Rotor_Info_dip2.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip2.rotor_info_arg[i][1] - first_th)/rotor2rotor_th) ;
        Rotor_Info_dip2.ROTER_STATUS |= 1<<temp;
    }
    for (i = 0; i<Rotor_Info_dip3.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip3.rotor_info_arg[i][1] - first_th)/rotor2rotor_th);
        Rotor_Info_dip3.ROTER_STATUS |= 1<<temp;
    }    
    for (i = 0; i<Rotor_Info_dip4.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip4.rotor_info_arg[i][1] - first_th)/rotor2rotor_th) ;
        Rotor_Info_dip4.ROTER_STATUS |= 1<<temp;
    }
    
    for (i = 0; i<Rotor_Info_dip1B.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip1B.rotor_info_arg[i][1] - first_th_b)/rotor2rotor_th);
        Rotor_Info_dip1B.ROTER_STATUS |= 1<<temp;
    }    
    for (i = 0; i<Rotor_Info_dip2B.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip2B.rotor_info_arg[i][1] - first_th_b)/rotor2rotor_th) ;
        Rotor_Info_dip2B.ROTER_STATUS |= 1<<temp;
    }
    for (i = 0; i<Rotor_Info_dip3B.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip3B.rotor_info_arg[i][1] - first_th_b)/rotor2rotor_th);
        Rotor_Info_dip3B.ROTER_STATUS |= 1<<temp;
    }   
    for (i = 0; i<Rotor_Info_dip4B.interrupt_num; i++)
    {
        temp = (uint8_t)((Rotor_Info_dip4B.rotor_info_arg[i][1] - first_th_b)/rotor2rotor_th) ;
        Rotor_Info_dip4B.ROTER_STATUS |= 1<<temp;
    }
    
    printf ("printf Check Rlt.\r\n");
    printf ("DIP1 Interrupt: %d, TOP: 0x%x, DIP1B Interrupt: %d,BOT: 0x%x.\r\n",Rotor_Info_dip1.interrupt_num, Rotor_Info_dip1.ROTER_STATUS, Rotor_Info_dip1B.interrupt_num, Rotor_Info_dip1B.ROTER_STATUS);
    printf ("DIP2 Interrupt: %d, TOP: 0x%x, DIP2B Interrupt: %d,BOT: 0x%x.\r\n",Rotor_Info_dip2.interrupt_num, Rotor_Info_dip2.ROTER_STATUS, Rotor_Info_dip2B.interrupt_num, Rotor_Info_dip2B.ROTER_STATUS);
    printf ("DIP3 Interrupt: %d, TOP: 0x%x, DIP3B Interrupt: %d,BOT: 0x%x.\r\n",Rotor_Info_dip3.interrupt_num, Rotor_Info_dip3.ROTER_STATUS, Rotor_Info_dip3B.interrupt_num, Rotor_Info_dip3B.ROTER_STATUS);
    printf ("DIP3 Interrupt: %d, TOP: 0x%x, DIP3B Interrupt: %d,BOT: 0x%x.\r\n",Rotor_Info_dip4.interrupt_num, Rotor_Info_dip4.ROTER_STATUS, Rotor_Info_dip4B.interrupt_num, Rotor_Info_dip4B.ROTER_STATUS);
    
    return 0;
}

#if 0
uint8_t Check_Rotor_Start(void)
{
    uint8_t ret = 0;
    
    if (CUR_SPJ_STATUS.rotor_check_flag == 0)
    {
        rotor_check_step = 1;
        VM_PWR_CTRL_On();       //HG1050 Power En
        delayms(100);
    }
    else
    {
        
    }
    
    switch (rotor_check_step)
    {
        case 1: //x,y,z 
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                CUR_SPJ_STATUS.x_step              = 35500;    
                CUR_SPJ_STATUS.y_step              = 16200;    
                CUR_SPJ_STATUS.z_step              = 310000;
                CUR_SPJ_STATUS.rotor_check_flag    = 1;
                rotor_check_step    = 2;
            }
            break;
        case 2: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                Rotor_Info.interrupt_num = 0;
                FTM0_Enable_Interrupt();          
                CUR_SPJ_STATUS.y_step              = 38500;
                rotor_check_step    = 3;
            }
            break;
        case 3: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {   
                FTM0_Disable_Interrupt();
                CUR_SPJ_STATUS.y_step              = -38500;
                rotor_check_step    = 4;
            }
            break;
        case 4: //dip 2
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                CUR_SPJ_STATUS.x_step              = 24400 - 35500;    //x_step = 30200;19300
                CUR_SPJ_STATUS.y_step              = 0;                //y_step = 30700;
                CUR_SPJ_STATUS.z_step              = 310000;
                rotor_check_step    = 5;
            }
            break;
        case 5: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Enable_Interrupt();
                CUR_SPJ_STATUS.y_step              = 38500;
                rotor_check_step    = 6;
            }
            break;
        case 6: //y
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Disable_Interrupt();
                CUR_SPJ_STATUS.y_step              = -38500;
                rotor_check_step    = 7;
            }                
            break;
        case 7: //gui 0
            if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
            {
                FTM0_Disable_Interrupt();
                rotor_data_handle(&Rotor_Info);
                CUR_SPJ_STATUS.z_step = 0;
                CUR_SPJ_STATUS.x_step = -CUR_SPJ_STATUS.total_x_step;
                CUR_SPJ_STATUS.y_step = -CUR_SPJ_STATUS.total_y_step;
                ret = 1;
                rotor_check_step    = 7;
                CUR_SPJ_STATUS.rotor_check_flag    = 0;
                VM_PWR_CTRL_Off();                       //HG1050 Power off
            }
            break;              
        default:
            break;
    }
    
    return ret;
}
#endif

