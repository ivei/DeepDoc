#ifndef __SYS_ISR_H_
#define __SYS_ISR_H_

#define     sysTick_ms      10

extern volatile uint8_t     Flag_1S;
extern volatile uint8_t     Flag_10MS;
extern volatile uint8_t     Flag_5MS;

//*****************************************************************************
extern void GoToLowPowerMode(void);
extern void BQFaultSignalTask(void);
extern void Timer1SecExpiredTask(void);
extern void TimerStartConvTask(void);
extern void DRDYSignalTask(void);
extern uint32_t SysTick_GetTimeOfMs(void);

#endif
