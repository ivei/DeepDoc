/******************************************************************************
 * ADS1118.c
 * ADC mode: Set the configuration to AIN0/AIN1, FS=+/-0.256, SS, DR=250sps, PULLUP on DOUT
 * Temperature mode: DR=250sps, PULLUP on DOUT
 *
 *  - Created on: Nov 15, 2012
 *	- modification data: 8 Jan. 2012
 *	- author: Wayne Xu (a0219294)
 *	- version: v1.3
 ******************************************************************************/
#include "common.h"
#include "spi.h"
#include "spi_if.h"
#include "main.h"
#include "gpio.h"
#include "qp_move_ctrl.h"
#include "SCI.h"
#include "ADS1118.h"

#define ADS1118_TransferByte(data)	SPI0_TransferByte(data)

#define ADS1118_CS_LOW()	SPI0_CS1_RESET()
#define ADS1118_CS_HIGH()	SPI0_CS1_SET()

/******************************************************************************
 * function: WriteSPI(unsigned int config, int mode)
 * introduction: write SPI to transmit the configuration parameter for ADS11118, and receive the convertion result.
 * parameters: config: configuration parameter of ADS11118's register, mode (0/1): internal temperature sensor, far-end temperature
 * return value: ADC result
*******************************************************************************/
signed short WriteSPI(unsigned int config, int mode)
{
	int msb;
	unsigned int temp;
    int config_reg = 0;

	temp = config;
	if (mode==1)
		temp = config | 0x8000;		            // mode == 1, means to read the data and start a new convertion.

    ADS1118_CS_LOW();

    msb = ADS1118_TransferByte(temp>>8);                //MSB    
    msb = (msb<<8) | ADS1118_TransferByte(temp&0xff);   //LSB    

    config_reg = ADS1118_TransferByte(temp>>8);                     //MSB    
    config_reg = (config_reg<<8) | ADS1118_TransferByte(temp&0xff); //LSB    

    ADS1118_CS_HIGH();

	return msb;
}

/******************************************************************************
 * function: ADS_Config (unsigned int mode)
 * introduction: configure and start conversion.
 * parameters:
 * mode = 0, ADS1118 is set to convert the voltage of integrated temperature sensor.
 * mode = 1, ADS1118 is set to convert the voltage of thermocouple.
 * return value:
*******************************************************************************/
//SPI mode 1 (CPOL = 0, CPHA = 1);
void ADS_Config(unsigned int channle)
{
	unsigned short tmp;
    
    if (channle == 0)     
        tmp = ADS1118_CH0 + ADS1118_GAIN2 + ADS1118_RATE860SPS + ADS1118_PULLUP + ADS1118_NOP + ADS1118_CNVRDY; // continuous mode
    else
        tmp = ADS1118_CH1 + ADS1118_GAIN2 + ADS1118_RATE860SPS + ADS1118_PULLUP + ADS1118_NOP + ADS1118_CNVRDY; // continuous mode
    
	WriteSPI(tmp, 0);
}

/******************************************************************************
 * function: ADS_Read(unsigned int mode)
 * introduction: read the ADC result and tart a new conversion.
 * parameters:
 * mode = 0, ADS1118 is set to convert the voltage of integrated temperature sensor.
 * mode = 1, ADS1118 is set to convert the voltage of thermocouple.
 * return value:result of last conversion
 */
signed short ADS_Read(unsigned int channle)
{
	unsigned short tmp;
	signed short   result;

    if (channle == 0)   
        tmp = ADS1118_CH0 + ADS1118_GAIN0 + ADS1118_RATE860SPS + ADS1118_PULLUP + ADS1118_NOP + ADS1118_CNVRDY; // continuous mode, single: ADS1118_OS, ADS1118_PWRDOWN
    else if (channle == 1)  
        tmp = ADS1118_CH1 + ADS1118_GAIN0 + ADS1118_RATE860SPS + ADS1118_PULLUP + ADS1118_NOP + ADS1118_CNVRDY; // continuous mode, single: ADS1118_OS, ADS1118_PWRDOWN
    else if (channle == 2)  
        tmp = ADS1118_CH2 + ADS1118_GAIN0 + ADS1118_RATE860SPS + ADS1118_PULLUP + ADS1118_NOP + ADS1118_CNVRDY; // continuous mode, single: ADS1118_OS, ADS1118_PWRDOWN
    else 
        tmp = ADS1118_CH3 + ADS1118_GAIN0 + ADS1118_RATE860SPS + ADS1118_PULLUP + ADS1118_NOP + ADS1118_CNVRDY; // continuous mode, single: ADS1118_OS, ADS1118_PWRDOWN
	
    // Write Config
	result = WriteSPI(tmp, 0);

	return result;
}

#define 	ADC_SAMPLING_NUM 	8
#pragma pack(1)
typedef struct
{
	int16_t Sampling_Array[ADC_SAMPLING_NUM];
	uint16_t Load_Array_Ptr;			
}ADC_Sampling;
#pragma pack()

ADC_Sampling     ADC_MOTOX_IBUS;
ADC_Sampling     ADC_MOTOY_IBUS;
ADC_Sampling     ADC_MOTOZ_IBUS;
ADC_Sampling     ADC_VSENSOR;

signed short Check_AD(ADC_Sampling *p_AD,uint16_t p_channel)
{
	uint16_t i;
	signed int p_AD_Value;
	
	if(p_AD->Load_Array_Ptr > ADC_SAMPLING_NUM - 1) 	
        p_AD->Load_Array_Ptr = 0;

    p_AD->Sampling_Array[p_AD->Load_Array_Ptr] = ADS_Read(p_channel);  //signed short
    
    p_AD->Load_Array_Ptr++;	
	
	p_AD_Value = 0;
	for(i=0;i<ADC_SAMPLING_NUM;i++)	
        p_AD_Value += p_AD->Sampling_Array[i];

    return (signed short)(p_AD_Value>>3);
}

#define adc_current_step_mul 1000
#define CadcOffset 0
#define MAX_CURR_MOTO_X      3000
#define MAX_CURR_MOTO_Y      3000
#define MAX_CURR_MOTO_Z      800

signed int ch1,ch2,ch3,ch4;//ch1=x,ch2=z,ch3=y
void Read_Bus_Curr_Volt(void)
{
    static unsigned char Ads1118Channle = 0;
    static unsigned char MOTO_CURR_ERR_COUNTER[3] = {0, 0, 0};

    switch(Ads1118Channle)
    {
        case 0:
            Ads1118Channle = 1; // next conv chl
            ch1 = (signed int)((Check_AD(&ADC_MOTOX_IBUS, Ads1118Channle)*adc_current_step_mul)/1000) + CadcOffset;
            if (ch1>MAX_CURR_MOTO_X)
            {
                MOTO_CURR_ERR_COUNTER[0]++;
                if (MOTO_CURR_ERR_COUNTER[0]>50)
                    CUR_SPJ_STATUS.SYS_ERR |= INFO_X_OVER_CUR;
            }
            else
            {
                MOTO_CURR_ERR_COUNTER[0] = 0;
            }
            break;
        case 1:
            Ads1118Channle = 2;
            ch2 = (signed int)((Check_AD(&ADC_MOTOZ_IBUS, Ads1118Channle)*adc_current_step_mul)/1000) + CadcOffset;
            if (ch2 > MAX_CURR_MOTO_Z)
            {
                MOTO_CURR_ERR_COUNTER[1]++;
                if (MOTO_CURR_ERR_COUNTER[1]>50)
                    CUR_SPJ_STATUS.SYS_ERR |= INFO_Y_OVER_CUR;
            }
            else
            {
                MOTO_CURR_ERR_COUNTER[1] = 0;
            }
            break;
        case 2:
            Ads1118Channle = 3;
            ch3 = (signed int)((Check_AD(&ADC_MOTOY_IBUS, Ads1118Channle)*adc_current_step_mul)/1000) + CadcOffset;
            if (ch3>MAX_CURR_MOTO_Y)
            {
                MOTO_CURR_ERR_COUNTER[2]++;
                if (MOTO_CURR_ERR_COUNTER[2]>50)
                    CUR_SPJ_STATUS.SYS_ERR |= INFO_Z_OVER_CUR;
            }
            else
            {
                MOTO_CURR_ERR_COUNTER[2] = 0;
            }
            break;
        case 3:
            Ads1118Channle = 0;
            ch4 = (signed int)((Check_AD(&ADC_VSENSOR, Ads1118Channle)*adc_current_step_mul)/1000) + CadcOffset;
            break;
        default:
            Ads1118Channle = 0;
            ADS_Read(Ads1118Channle);
            break;
    }  
}
