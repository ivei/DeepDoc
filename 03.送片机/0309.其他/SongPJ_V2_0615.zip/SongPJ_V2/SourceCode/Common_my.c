#include "Common_my.h"

void Data_Shift(unsigned char* pBuf, int len, int shift)
{
	int i;

	if(shift < 0)
	{
		for(i = 0; i < len - (-shift); i++)
		{
			pBuf[i] = pBuf[i + (-shift)];
		}
	}
	else
	{
		for(i = len - 1; i >= shift; i--)
		{
			pBuf[i] = pBuf[i - shift];
		}
	}
}

int myStrStr(char* pStr, int strLen, char* pItem, int itemLen)
{
	int i;

	for(i = 0; i < strLen - itemLen + 1; i++)
	{
		if(memcmp(&pStr[i], pItem, itemLen) == 0)
		{
			return i;
		}
	}
	return (-1);
}

unsigned char CheckSum(unsigned char* pBuf, int len)
{
	unsigned char sum = 0;
	int i;

	for(i = 0; i < len; i++)
	{
		sum += pBuf[i];
	}
	return sum;
}

// GPRS
// Ҫ���͵�����buf----Ҫ���͵����ݳ���-----ת���������buf--����----ʵ��ת���󳤶�
bool PPP_EncodePacket(unsigned char* pBuf_src, int len_src,
						unsigned char* pBuf_dst, int size_dst, int* pLen_dst)
{
	int i;
	int len_dst;
	unsigned char tmp;
	
	len_dst = 0;
	pBuf_dst[len_dst++] = 0x7e;  // ��ʼ��0x7e
	for(i = 0; i < len_src; i++)
	{
		if(len_dst > size_dst - 2)
		{
			return false;
		}
		
		tmp = pBuf_src[i];
		if(tmp == 0x7e)
		{
			pBuf_dst[len_dst++] = 0x7d;
			pBuf_dst[len_dst++] = 0x5e;  // tmp ^ 0x20
		}
		else if(tmp == 0x7d)
		{
			pBuf_dst[len_dst++] = 0x7d;
			pBuf_dst[len_dst++] = 0x5d;  // tmp ^ 0x20
		}
#if 1
		else if(tmp == 0x1a)
		{
			pBuf_dst[len_dst++] = 0x7d;
			pBuf_dst[len_dst++] = 0x3a;  // tmp ^ 0x20
		}
#endif
		else
		{
			pBuf_dst[len_dst++] = tmp;
		}		
	}
	if(len_dst >= size_dst)
	{
		return false;
	}
	pBuf_dst[len_dst++] = 0x7e;  // ������Ҳ��0x7e
	
	*pLen_dst = len_dst;
	return true;
}

bool PPP_DecodePacket(unsigned char* pBuf_src, int len_src, int* pEnd_src,
						unsigned char* pBuf_dst, int size_dst, int* pLen_dst)
{
	int i;
	int len_dst;
	unsigned char tmp;
	
	for(i = 0; i < len_src - 1; i++)  // ������ʼ��
	{
		if((pBuf_src[i] == 0x7e) && (pBuf_src[i + 1] != 0x7e))
		{
			i++;
			break;
		}
	}
	if(i >= len_src - 1)  // �Ҳ�����ʼ��, ����ʧ��
	{
		return false;
	}
	
	len_dst = 0;
	for(; i < len_src - 1; i++)  // len_src-1: ��ֹ����Խ��
	{
		if(len_dst >= size_dst)
		{
			return false;
		}
		
		tmp = pBuf_src[i];
		if(tmp == 0x7e)  // �ڶ���0x7e, Ϊ������
		{
			*pEnd_src = i + 1;
			*pLen_dst = len_dst;
			return true;
		}
		
		if(tmp == 0x7d)
		{
			i++;
			pBuf_dst[len_dst++] = pBuf_src[i] ^ 0x20;
		}
		else
		{
			pBuf_dst[len_dst++] = tmp;
		}
	}
	
	if((i == len_src - 1) && (pBuf_src[len_src - 1] == 0x7e))
	{
		*pEnd_src = len_src;
		*pLen_dst = len_dst;
		return true;
	}
	
	return false;
}

//bool uart_ParsePacket(unsigned char* pBuf, int bufLen, int* pBufLen_used,
//		uart_packetHead_t* pPacket, int packetSize, int* pPacketLen)
//{
//	bool	bRet;
//	int		len;
//	int		packetLen;
//	int		offset = 0;
//	
//	while(offset < bufLen)
//	{
//		bRet = PPP_DecodePacket(&pBuf[offset], bufLen - offset, &len,
//										(unsigned char*)pPacket, packetSize, &packetLen);
//		if(bRet != true)
//		{
//			goto out_err;
//		}
//		printf("PPP decode successfully.\r\n");
//		
//		offset += len;
//		
//		if(packetLen == sizeof(uart_packetHead_t) - 1 + pPacket->len + 1) //+ second crc
//		{
//			if((pPacket->start == 0x55)		&&
//				(pPacket->stop == 0xaa)		&&
//				(pPacket->checksum == CheckSum((unsigned char*)pPacket, (int)&((uart_packetHead_t*)0)->checksum))	&&
//				(((unsigned char*)pPacket)[packetLen - 1] == CheckSum((unsigned char*)pPacket->buf, pPacket->len)))
//			{
//				*pBufLen_used	= offset;
//				*pPacketLen		= packetLen;
//				return true;
//			}
//			else
//			{
//				if(pPacket->checksum != CheckSum((unsigned char*)pPacket, (int)&((uart_packetHead_t*)0)->checksum))
//				{
//					printf("Packet header checksum error.\r\n");
//				}
//				if(((unsigned char*)pPacket)[packetLen - 1] != CheckSum((unsigned char*)pPacket->buf, pPacket->len))
//				{
//					printf("Packet data checksum error.\r\n");
//				}
//			}
//		}
//	}
//	
//out_err:
//	*pBufLen_used = offset;
//	return false;
//}

//bool uart_SetupPacket(uart_packetHead_t* pPacket, unsigned char* pBuf, int bufSize, int* pBufLen)
//{
//	pPacket->start			= 0x55;
//	//pPacket->iFrame		= 0x00;
//    //pPacket->cmd		    = 0x00;
//    //pPacket->len		    = 0x00;
//	pPacket->deviceNo		= 0x00;//deviceParam.config.deviceNo;
//	pPacket->stop			= 0xaa;
//	pPacket->checksum		= CheckSum((unsigned char*)pPacket, (int)&((uart_packetHead_t*)0)->checksum);
//	pPacket->buf[pPacket->len]	= CheckSum(pPacket->buf, pPacket->len);
//	return PPP_EncodePacket((unsigned char*)pPacket, sizeof(uart_packetHead_t) - 1 + pPacket->len + 1,
//						pBuf, bufSize, pBufLen);
//}

