#ifndef __SCI_H_
#define __SCI_H_

//#define UI_MAX_RX_BUF_LEN       64
//#define UI_MAX_TX_BUF_LEN       64

#define SPJ_SEND_BUF(pTxbuff, length)  Uart0_Send_Bytes(pTxbuff, length)

typedef enum 
{
    CMD_SUCC  = 0x00,
    CMD_FAIL  = 0x01,
    CMD_RECV  = 0x02,
}SPJ_COMM_STATUS;

//---------------------------------------------------------------
#define FAIL_NONE       0x00   

//SPJ_BP_STATUS
#define FAIL_GET_ING    0x01    //����ȡƬ
#define FAIL_RTN_ING    0x02    //���ڻ�Ƭ
#define FAIL_ZBT_ON     0x04    //�ز�̨�в�Ƭ
#define FAIL_NOCALIB    0x08    //δУ׼
#define FAIL_OVER_ZBP   0x10    //ȡƬ�������ֵ
#define FAIL_ZBT_NONE   0x20    //�ز�̨û�в�Ƭ
#define FAIL_MOTO_MOVE  0x40    //�����������
#define FAIL_TIMEOUT    0x80    //��ʱ

//---------------------------------------------------------------
//CUR_SPJ_STATUS.SYS_ERR
#define INFO_JT_ON          0x01    //��ͷ�в�Ƭ
#define INFO_ZBT_ON         0x02    //�ز�̨�в�Ƭ
#define INFO_X_OVER_CUR     0x04    //X����
#define INFO_Y_OVER_CUR     0x08    //
#define INFO_Z_OVER_CUR     0x10    //
#define INFO_MOTO_FAULT     0x20
#define INFO_MOTO_OVER_POS  0x40

//typedef struct
//{
//	uint8_t*	    pRxBuf;
//	int				rxBufSize;
//	int				rxBufLen;
//}uart_ui_param_t;   

#pragma pack(1)
typedef struct
{
	uint16_t	start;		// EB 90
	uint8_t		len;        // dir 2 crc
    uint8_t     dir;
	uint8_t		cmd;
	uint16_t    checksum;	// ͷУ��, ��len��data
	uint8_t		buf[1];
} SPJ_packetHead_t;
#pragma pack()

#pragma pack(1)
typedef struct
{
	uint16_t	start;		// EB 90
	uint8_t		len;        // dir 2 crc
    uint8_t     dir;
	uint8_t		cmd;
    uint8_t		result;     // ִ�н��
    uint8_t		reason;     // ʧ��ԭ��
	uint16_t    checksum;	// ͷУ��, ��len��data
} SPJ_COMM_Head_t;
#pragma pack()

#pragma pack(1)
typedef struct  //��ȡƬ����Ϣ
{
	uint16_t	start;		// EB 90
	uint8_t		len;        // dir 2 crc
    uint8_t     dir;
	uint8_t		cmd;
    uint8_t		result;
    uint8_t		reason;
    uint8_t     data;
	uint16_t    checksum;	// ͷУ��, ��len��data
} SPJ_COMM_ZBP_SHIFT_Head_t; 
#pragma pack()

#pragma pack(1)
typedef struct  //��鲣Ƭ״̬
{
	uint16_t	start;		// EB 90
	uint8_t		len;        // dir 2 crc
    uint8_t     dir;
	uint8_t		cmd;
    uint8_t		result;
    uint8_t		reason;
    uint16_t	data_status[8];
	uint16_t    checksum;	// ͷУ��, ��len��data
} SPJ_COMM_ZBP_STATUS_Head_t;
#pragma pack()

typedef enum
{
	SPJ_SUBSTATE_IDLE 		= 0x00,
    SPJ_SUBSTATE_INIT 		= 0x01,    	// ��ʼ��
    SPJ_SUBSTATE_STOP 		= 0x02,    	// ��ͣ    
    SPJ_SUBSTATE_STATUS 	= 0x03,    	// ��ȡ�ز�Ƭ״̬ 
    SPJ_SUBSTATE_GET  		= 0x04,   	// ȡƬ  
    SPJ_SUBSTATE_RETURN 	= 0x05,    	// ��Ƭ  
    SPJ_SUBSTATE_CURRENT 	= 0x06,    	// ��ǰƬ��  
    SPJ_SUBSTATE_SWITCH 	= 0x07,    	// �л�Ƭ��
    SPJ_SUBSTATE_INFO 		= 0x08,    	// ��Ϣ�ϱ�
	SPJ_SUBSTATE_PWRON_INFO = 0x09   	// �����ϱ���Ϣ
} spj_subState_t;

#define CMD_SPJ_INIT	    0x01
#define CMD_SPJ_STOP	    0x02
#define CMD_SPJ_STATUS	    0x03
#define CMD_SPJ_GET	        0x04
#define CMD_SPJ_RETURN	    0x05
#define CMD_SPJ_CURRENT	    0x06
#define CMD_SPJ_SWITCH	    0x07
#define CMD_SPJ_INFO	    0x08

extern uint16_t CRC16(uint8_t *pBuf, int nLen);
//extern void dprintf(char *pcString, ...);
////extern void Data_Shift(uint8_t* pBuf, int len, int shift);
//extern int Uart1_Receive(uint8_t* pBuf, int size);
//extern int USART1_Send_Buf(uint8_t* pBuf, int len);
extern _Bool SPJ_ParsePacket(uint8_t* pBuf, int bufLen, int* pBufLen_used, uint8_t* pData, int dataLen_max, int* pDataLen);
extern int deal_packet(unsigned char *buf, unsigned int len);
extern void SPJ_Send_Command_Ack(uint8_t COMM, SPJ_COMM_STATUS status, uint8_t reason);

#endif
