#ifndef __DEVICE_DRIVER_H_
#define __DEVICE_DRIVER_H_

extern const uint16_t moto_period[4];

extern void InitMCU(void);
extern void ADC0_Init(void);
extern void IPCInit(void);
extern void Fault_KBI0_Init(void);  //KBI0---PA0(CH0)
extern void PIT0ch1_Init(void);     //10ms capture current
extern void PIT0ch0_Init(void);  
extern void PIT0ch0_Enable_CHL(unsigned char Axis);
extern void PIT0ch0_Disable_CHL(unsigned char Axis);
extern void FTM0_Enable_Interrupt(void);
extern void FTM0_Disable_Interrupt(void);
extern void FTM0_Init(void);
extern void FTM2_Disable_CHL(unsigned char Axis);
extern void FTM2_Enable_CHL(unsigned char Axis);
extern void FTM2_Init(void);
extern void FTM1_Disable_CHL(unsigned char Axis);
extern void FTM1_Enable_CHL(unsigned char Axis);
extern void FTM1_Init(void);
extern void Init1SecTimer(void);    // RTC
extern void Disable1SecTimer(void);
extern signed short adcCurrent_Handle(signed short *arr, int n);
extern void Irq_Interrupt_Init(void); //PTI4
extern void I2C0_User_Init(void);
extern int I2C0_Master_Read(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len);
extern int I2C0_Master_Write(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len);
extern void I2C1_User_Init(void);
extern int I2C1_Master_Read(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len);
extern int I2C1_Master_Write(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len);
extern void InitSysCtrlports(void);

extern void delayms(unsigned short ms);  
extern void delayus(unsigned short us) ;

#endif
