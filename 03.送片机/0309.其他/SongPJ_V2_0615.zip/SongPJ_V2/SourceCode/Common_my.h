#ifndef _COMMON_MY_H_
#define _COMMON_MY_H_

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#ifndef min
	#define min(a, b)	(((a) < (b))? (a) : (b))
#endif
#ifndef max
	#define max(a, b)	(((a) > (b))? (a) : (b))
#endif
#define median(a, b, c) min(min(max((a), (b)), max((a), (c))), max((b), (c)))

#define ARRAY_SIZE(array)	(sizeof(array) / sizeof((array)[0]))
	
#define Char2BCD(data)		((((data) / 10) << 4 )| ((data) % 10))
#define BCD2Char(data)		((((data) >> 4) * 10) + ((data) & 0x0f))
	
extern void Data_Shift(unsigned char* pBuf, int len, int shift);
extern int myStrStr(char* pStr, int strLen, char* pItem, int itemLen);
extern unsigned char CheckSum(unsigned char* pBuf, int len);

extern bool PPP_EncodePacket(unsigned char* pBuf_src, int len_src,
						unsigned char* pBuf_dst, int size_dst, int* pLen_dst);
extern bool PPP_DecodePacket(unsigned char* pBuf_src, int len_src, int* pEnd_src,
						unsigned char* pBuf_dst, int size_dst, int* pLen_dst);
//extern bool uart_ParsePacket(unsigned char* pBuf, int bufLen, int* pBufLen_used, \
		uart_packetHead_t* pPacket, int packetSize, int* pPacketLen);
//extern bool uart_SetupPacket(uart_packetHead_t* pPacket, unsigned char* pBuf, int bufSize, int* pBufLen);

#endif
