/******************************************************************************
*
* Freescale Semiconductor Inc.
* (c) Copyright 2013 Freescale Semiconductor, Inc.
* ALL RIGHTS RESERVED.
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* @file isr.h
*
* @author Freescale
*
* @version 0.0.1
*
* @date Jun. 25, 2013
*
* @brief define interrupt service routines referenced by the vector table. 
*
* Note: Only "vectors.c" should include this header file.
*
*******************************************************************************
******************************************************************************/

#ifndef __ISR_H
#define __ISR_H


/* Example */
/*
#undef  VECTOR_036
#define VECTOR_036 RTC_Isr

// ISR(s) are defined in your project directory.
extern void RTC_Isr(void);
*/

/*!
 * @brief define interrupt service routine for different vectors.
 *
 */
 
#undef  VECTOR_033                          /*!< FTM0 */ 
#define VECTOR_033      FTM0_PORT_ISR        /*!< Vector 33 points to FTM0 interrupt service routine */

#undef  VECTOR_035                          /*!< FTM2 */ 
#define VECTOR_035      FTM2_PORT_ISR       /*!< Vector 35 points to FTM0 interrupt service routine */

#undef  VECTOR_034                          /*!< FTM1 */ 
#define VECTOR_034      FTM1_PORT_ISR       /*!< Vector 34 points to FTM0 interrupt service routine */

#undef  VECTOR_036
#define VECTOR_036      RTC1SecISR          /*!< Vector 36 points to RTC interrupt service routine */

#undef  VECTOR_039 
#define VECTOR_039      PIT0ch1_5ms_isr   

#undef  VECTOR_038 
#define VECTOR_038      PIT0ch0_200us_isr  

#undef  VECTOR_023 
#define VECTOR_023      IRQ_Interrupt_isr   

#undef  VECTOR_028
#define VECTOR_028      UART0_RX_ISR
//#undef  VECTOR_029
//#define VECTOR_029      UART1_Isr
#undef  VECTOR_030                         /*!< UART2 */ 
#define VECTOR_030      UART2_RX_ISR       /*!< Vector 30 points to UART2 interrupt service routine */

extern void RTC1SecISR(void);
extern void FTM0_PORT_ISR(void);
extern void FTM2_PORT_ISR(void);
extern void FTM1_PORT_ISR(void);
extern void PIT0ch1_5ms_isr(void);
extern void PIT0ch0_200us_isr(void);
extern void IRQ_Interrupt_isr(void);
//extern void BQ76PL536_DRDY_ISR(void);
extern void UART0_RX_ISR(void);
//extern void UART1_Isr(void);
extern void UART2_RX_ISR(void);

#endif  //__ISR_H

/* End of "isr.h" */
