#include "common.h"
#include "adc.h"
#include "spi.h"
#include "spi_if.h"
#include "sim.h"
#include "i2c.h"
#include "rtc.h"
#include "main.h"
#include "uart_if.h"
#include "uart.h"
#include "gpio.h"
#include "ads1118.h"
#include "sysinit.h"
#include "StepMotor.h"
#include "device_driver.h"

/* ADC Setting */
#define ADC_INPUT_SELECT_DCB_I          7        /* DC-Bus current  ADC input  */
#define ADC_INPUT_SELECT_DCB_V          8        /* DC-Bus voltage  ADC input  */
#define ADC_INPUT_SELECT_ADCDISABLE     31

const uint16_t moto_period[4] = {942, 589, 785, 4000}; // �����������Ƶ��

volatile unsigned int       uDcbSum32;
volatile unsigned char      adcSensing_AverageUDCBCounter;
volatile signed short       ADValue_Voltage;
volatile unsigned short     uDcbFilt;

/* ADC sensing parameters */
#define ADC_SENSING_CALIBRATION_COUNT   64     /* ADC current sensing callibration counter */
#define ADC_SENSING_SAMPLE_COUNT        16     /* ADC current sensing sample counter */

volatile signed short   ADVALUE_Current;
volatile _Bool          ICalibrated;   
volatile unsigned int   iDcbSum32;
volatile signed short	iDcboffset;
volatile unsigned char 	adcSensing_CalibrationCounter2 = 0;
volatile unsigned char  adcSensing_SampleCounter = 0;
signed short            ADVALUE_SampleCurrent[ADC_SENSING_SAMPLE_COUNT];
volatile signed short   iDcb;

/**
* @brief Function Name:  InitMCU.                                                
* @brief Description  :  Initializes the MSP430 peripherals and modules.
* @param parameters   :  none                                                   
* @return Value       :  none                                                   
*/  
void InitMCU(void)
{
    /* Perform processor initialization */
    sysinit(); // Init uart2,TERM_PORT UART2_TX PTD7, UART2_RX PTD6
    IPCInit(); // Setup NVIC
    UART_EnableRxBuffFullInt(TERM_PORT);
    enable_irq(UART2_IRQn);

    //*Initialize IO ports input/output signals*/ 
    InitSysCtrlports();
	
    FTM0_Init();    // ���⴫�����ж�ʹ��FTM0���벶��
	FTM1_Init();    // X��
    FTM2_Init();    // Y��
    
    Uart0_Init(); //UART0_RX PTB0, UART0_TX PTB1  
    //Uart1_Init();
 
    //Init SPI module
    init_spi0();    // CPOL = 0/CPHA = 1
    //init_spi1();  // CPOL = 0/CPHA = 0
    ADS_Config(0);  // SPI0, CPOL = 0/CPHA = 1
   
//    while(1)
//    {
//        test = ADS_Read(1);
//        delayms(200);
//    }
    
    //ADC0_Init();
    PIT0ch1_Init();         // 5ms
	PIT0ch0_Init();         // 200us Z��
    Irq_Interrupt_Init();   // �����ж�
    //*Initilize 1s system periodic interrupt*/
    Init1SecTimer();

    //__enable_interrupt(); // enable global interrupts
}

void Irq_Interrupt_Init(void) //PTI4
{
    SIM->PINSEL |= SIM_PINSEL_IRQPS(5); //PTI4
    SIM->SCGC   |= SIM_SCGC_IRQ_MASK; 
    IRQ->SC     |= IRQ_SC_IRQPE_MASK | IRQ_SC_IRQIE_MASK;   //�������½���
}

void ADC0_Init(void)
{
//    SIM->SCGC |= SIM_SCGC_ADC_MASK;//clock enable
//    ADC->SC1 = ADC_INPUT_SELECT_ADCDISABLE;//adc disable
//    ADC->APCTL1 = 0x380;// enable ad channle 7, 8, 9
//    ADC->SC3 = ADC_SC3_MODE(2) | ADC_SC3_ADIV(3);//12bit,fADCK = 6Mhz
//   
//    //ADC->SC2 |= ADC_SC2_ADTRG_MASK;//hardware trig selected
//    ADC->SC2 &= ~ADC_SC2_ADTRG_MASK; //software trig selected
//   
//    //SIM->SOPT &= ~SIM_SOPT_ADHWT_MASK;//RTC overflow to trig ADC
//    //enable_irq(ADC0_IRQn);
    
    ADC_ConfigType  sADC_Config = {0};

    //SIM_TriggerADCByPIT();
    sADC_Config.u16PinControl |= 0x380;// enable ad channle 7, 8, 9
    
    /* initiaze ADC module */
    sADC_Config.u8ClockDiv = ADC_ADIV_DIVIDE_4;
    sADC_Config.u8ClockSource = CLOCK_SOURCE_BUS_CLOCK;
    sADC_Config.u8Mode = ADC_MODE_12BIT;
    //sADC_Config.sSetting.bIntEn = 1;
    //sADC_Config.u8FiFoLevel = ADC_FIFO_LEVEL3;
    //ADC_SetCallBack(ADC_CallBack);
    ADC_Init(ADC, &sADC_Config);
}

void IPCInit(void)
{
    set_irq_priority (IRQ_IRQn, 1);     // irq interrupt
    set_irq_priority (FTM2_IRQn, 2); 
	set_irq_priority (FTM1_IRQn, 3); 
    set_irq_priority (PIT_CH0_IRQn, 7); // PWM update interrupt
	set_irq_priority (PIT_CH1_IRQn, 6); // PWM update interrupt
    set_irq_priority (KBI1_IRQn, 4);    // hallC interrupt
    set_irq_priority (FTM0_IRQn, 5);    // hallA,hallB interrupt 
   
    set_irq_priority (UART0_IRQn, 8);   // uart0 interrupt
    set_irq_priority (UART2_IRQn, 9);   // uart2 interrupt
    set_irq_priority (RTC_IRQn, 10);    // RTC interrupt
}

//KBI1->SC |= KBI_SC_KBACK_MASK;//clear interrupt flag
//KBI1->SC &= ~KBI_SC_KBIE_MASK;
//KBI1->SC |= KBI_SC_KBIE_MASK;

void Fault_KBI0_Init(void)//KBI0---PA0(CH0)
{
    SIM->SCGC |= SIM_SCGC_KBI0_MASK;
    
    KBI0->SC &= ~KBI_SC_KBIE_MASK;//Disable interrupt
    
    PORT->PUE0 |= PORT_PUE0_PTAPE0_MASK;    //Pull up for PTA0
    
    //KBI0->ES &= ~0x01;    //Default Rising Edge    
    KBI0->PE |= 0x01;       //KBI_PE_KBIPE(0);//enable KBI10
    KBI0->SC |= KBI_SC_KBACK_MASK;  //Clean Interrupt Flag
    KBI0->SC |= KBI_SC_KBIE_MASK;   //Enable Interrupt
    //PORT->IOFLT |= PORT_IOFLT_FLTKBI1(1); //filter for busclock/2;
    enable_irq(KBI0_IRQn);
}

void PIT0ch1_Init(void)//5ms capture current
{
    SIM->SCGC |= SIM_SCGC_PIT_MASK; // enable system clock for this peripherals
    PIT->MCR = 0x00;  // enable the timer, no other settings can be made unless this bit is cleared
    /*need 5 ms of interrupt periode, therefore value register (overflow event and interrupt calling
    should be calculated:                                        
    timer_overflow =   core_freq * 125 = 3000(0xBB8)   @ 20 MHz clock,    */
    PIT->CHANNEL[1].LDVAL = (120000-1);     // Timer counts down to zero. bus clock /2
    PIT->CHANNEL[1].TCTRL = 0x01;           // enable PIT
    
    PIT->CHANNEL[1].TFLG |= PIT_TFLG_TIF_MASK ; 
    PIT->CHANNEL[1].TCTRL |= PIT_TCTRL_TIE_MASK; 
    
    enable_irq(PIT_CH1_IRQn);//enable interrupt for channel 1
}

void PIT0ch0_Init(void)//5ms capture current
{
    SIM->SCGC |= SIM_SCGC_PIT_MASK; // enable system clock for this peripherals
    PIT->MCR = 0x00;  // enable the timer, no other settings can be made unless this bit is cleared
    /*need 5 ms of interrupt periode, therefore value register (overflow event and interrupt calling
    should be calculated:                                        
    timer_overflow =   core_freq * 125 = 3000(0xBB8)   @ 20 MHz clock,    */
    PIT->CHANNEL[0].LDVAL = (2000-1);     // Timer counts down to zero. bus clock /2
    PIT->CHANNEL[0].TCTRL = 0x01;       	// enable PIT
    
    //PIT->CHANNEL[0].TFLG |= PIT_TFLG_TIF_MASK ; 
    //PIT->CHANNEL[0].TCTRL |= PIT_TCTRL_TIE_MASK; 
    
    enable_irq(PIT_CH0_IRQn);//enable interrupt for channel 1
}

void PIT0ch0_Disable_CHL(unsigned char Axis)
{
    //FTM2->CONTROLS[Axis].CnSC &= ~FTM_CnSC_CHIE_MASK ;//Disable interrupt
	PIT->CHANNEL[0].TCTRL &= ~PIT_TCTRL_TIE_MASK; 
}

void PIT0ch0_Enable_CHL(unsigned char Axis)
{
	PIT->CHANNEL[0].TFLG &= ~PIT_TFLG_TIF_MASK ;
    PIT->CHANNEL[0].TCTRL |= PIT_TCTRL_TIE_MASK; 
}

void FTM2_Disable_CHL(unsigned char Axis)
{
    FTM2->CONTROLS[Axis].CnSC &= ~FTM_CnSC_CHIE_MASK ;//Disable interrupt
}

void FTM2_Enable_CHL(unsigned char Axis)
{
    FTM2->CONTROLS[Axis].CnSC &= ~FTM_CnSC_CHF_MASK ;
    FTM2->CONTROLS[Axis].CnSC |= FTM_CnSC_CHIE_MASK ; //Enable interrupt
}

void FTM1_Init(void)// compare interrupt
{    
    SIM->SCGC |= SIM_SCGC_FTM1_MASK; // enable system clock for this peripherals
    
    FTM1->SC |= FTM_SC_PS(2);   //4��Ƶ
        
    /* Enable Channle 0*/
    //FTM2->CONTROLS[0].CnSC |= FTM_CnSC_CHIE_MASK; /* Enable channel 2 interrupt */
    FTM1->CONTROLS[0].CnSC |= FTM_CnSC_MSA_MASK;  /* Channel as Output compare mode */
    
    /* Enable Channle 1*/
    //FTM2->CONTROLS[1].CnSC |= FTM_CnSC_CHIE_MASK; /* Enable channel 2 interrupt */
    //FTM1->CONTROLS[1].CnSC |= FTM_CnSC_MSA_MASK;  /* Channel as Output compare mode */
        
    /* Enable Channle 2*/
    //FTM2->CONTROLS[2].CnSC |= FTM_CnSC_CHIE_MASK; /* Enable channel 2 interrupt */
    //FTM1->CONTROLS[2].CnSC |= FTM_CnSC_MSA_MASK;  /* Channel as Output compare mode */
    
    
    FTM1->SC |= FTM_SC_CLKS(1); /*FTM2 use system clock*/	
    
    enable_irq(FTM1_IRQn);//enable interrupt for channel 1
}

void FTM1_Disable_CHL(unsigned char Axis)
{
    FTM1->CONTROLS[0].CnSC &= ~FTM_CnSC_CHIE_MASK ;//Disable interrupt
}

void FTM1_Enable_CHL(unsigned char Axis)
{
    FTM1->CONTROLS[0].CnSC &= ~FTM_CnSC_CHF_MASK ;
    FTM1->CONTROLS[0].CnSC |= FTM_CnSC_CHIE_MASK ; //Enable interrupt
}

void FTM2_Init(void)// compare interrupt
{
    //SIM_RemapFTM2CH2ToPTC2();
    //SIM_RemapFTM2CH1ToPTC1();
    //SIM_RemapFTM2CH0ToPTC0();
    
    SIM->SCGC |= SIM_SCGC_FTM2_MASK; // enable system clock for this peripherals
    
    FTM2->SC |= FTM_SC_PS(2);   //4��Ƶ
        
    /* Enable Channle 0*/
    //FTM2->CONTROLS[0].CnSC |= FTM_CnSC_CHIE_MASK; /* Enable channel 2 interrupt */
    FTM2->CONTROLS[0].CnSC |= FTM_CnSC_MSA_MASK;  /* Channel as Output compare mode */
    
    /* Enable Channle 1*/
    //FTM2->CONTROLS[1].CnSC |= FTM_CnSC_CHIE_MASK; /* Enable channel 2 interrupt */
    //FTM2->CONTROLS[1].CnSC |= FTM_CnSC_MSA_MASK;  /* Channel as Output compare mode */
        
    /* Enable Channle 2*/
    //FTM2->CONTROLS[2].CnSC |= FTM_CnSC_CHIE_MASK; /* Enable channel 2 interrupt */
    //FTM2->CONTROLS[2].CnSC |= FTM_CnSC_MSA_MASK;  /* Channel as Output compare mode */
    
    /*Select interrupt frequency*/
	//FTM2->CONTROLS[0].CnV = FTM_CnV_VAL(period[0]) ;	 
	//FTM2->CONTROLS[1].CnV = FTM_CnV_VAL(period[1]) ;	 
	//FTM2->CONTROLS[2].CnV = FTM_CnV_VAL(period[2]) ;	 
    
    //FTM2->CNT = 0;
    //FTM2->MOD = 5000; //���ô˾�����ֻ��һ��
    
    FTM2->SC |= FTM_SC_CLKS(1); /*FTM2 use system clock*/	
    
    enable_irq(FTM2_IRQn);//enable interrupt for channel 1
}

void FTM0_Enable_Interrupt(void)
{
    FTM0->CONTROLS[0].CnSC &= ~FTM_CnSC_CHF_MASK ;
    FTM0->CONTROLS[0].CnSC |= FTM_CnSC_CHIE_MASK ; //Enable interrupt
}

void FTM0_Disable_Interrupt(void)
{
    FTM0->CONTROLS[0].CnSC &= ~FTM_CnSC_CHIE_MASK ;//Disable interrupt
}

void FTM0_Init(void)//���⴫�����ж�ʹ��FTM0���벶��
{
    SIM->SCGC |= SIM_SCGC_FTM0_MASK;
    
    //FTM0->MODE |= FTM_MODE_WPDIS_MASK;
    FTM0->CONTROLS[0].CnSC |= FTM_CnSC_ELSA_MASK | FTM_CnSC_ELSB_MASK;      //FTM0->CONTROLS[0].CnSC |= FTM_CnSC_ELSA_MASK ;//Rising Edge 
    //FTM0->CONTROLS[1].CnSC |= FTM_CnSC_ELSA_MASK | FTM_CnSC_ELSB_MASK;
    FTM0->MOD = 0xFFFF;
    FTM0->SC |= FTM_SC_CLKS(1) | FTM_SC_PS(7);//the isr is not enabled
    
    //FTM0CH0 = A0
    //SIM->PINSEL |= SIM_PINSEL_FTM0PS0_MASK | SIM_PINSEL_FTM0PS1_MASK;//FTM0CH0:PTB2. FTM0CH1:PTB3;
    
    //PORT->IOFLT |= PORT_IOFLT_FLTFTM0(1);//filter for busclock/2;
    enable_irq(FTM0_IRQn);
}

/**
* @brief Function Name: Init1SecTimer     .                                             
* @brief Description  : initializes the 1 sec timer, 
* TimeAx used to create a 1Sec delay.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/
void Init1SecTimer(void)    // RTC
{
    RTC_ConfigType      sRTCConfig;
    uint16_t            u16ModuloValue;
    RTC_ConfigType     *pRTCConfig = &sRTCConfig;  

    /* configure RTC to 1Hz interrupt frequency */ 
    u16ModuloValue              = 24000 - 1;                /*!< 20000 = 1s */
    
    pRTCConfig->u16ModuloValue  = u16ModuloValue;
    pRTCConfig->bInterruptEn    = RTC_INTERRUPT_ENABLE;     /*!< enable interrupt */
    pRTCConfig->bClockSource    = RTC_CLKSRC_BUS;           /*!< clock source is 24Mhz */
    pRTCConfig->bClockPresaler  = RTC_CLK_PRESCALER_1000;   /*!< prescaler is 1000 */
    //RTC_SetCallback(RTC_Task);
		RTC_Init(pRTCConfig);    

//    SIM->SCGC |= SIM_SCGC_RTC_MASK;
//    RTC->MOD = RTC_MOD_MOD(0x753-0x01);
//    RTC->SC |= RTC_SC_RTCLKS(3) | RTC_SC_RTCPS(1);
//    SIM->SOPT |= SIM_SOPT_ADHWT(0); // enable RTC's overflow to trig ADC
//    enable_irq(36-16);
}

/**
* @brief Function Name: Disable1SecTimer.                                                  
* @brief Description  : Disables the 1 sec timer.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/
void Disable1SecTimer(void)
{

}

//void bubbleSort(uint16_t *arr, int n) // ����
signed short adcCurrent_Handle(signed short *arr, int n) 
{
    int i;
    unsigned int m = 0;
//    unsigned short temp;
    
//    for (i = 0; i<n - 1; i++)
//    {
//        for (int j = 0; j < n - i - 1; j++)
//        {
//            //���ǰ������Ⱥ���󣬽��н���
//            if (arr[j] > arr[j + 1]) 
//            {
//                temp = arr[j]; 
//                arr[j] = arr[j + 1]; 
//                arr[j + 1] = temp;
//            }
//        }
//    }
    //for(i=2; i<n-2; i++)
    for(i=0; i<n; i++)
    {
        m += arr[i];
    }
    return (signed short)(m>>4);
}

void I2C0_User_Init(void)// A2=SDA, A3=SCL
{
    I2C_ConfigType  sI2C_Config = {0};
    
    //SIM_RemapI2CToPTA_2_3(); //default
    
    /* Initialize I2C module with poll mode */
    sI2C_Config.u16F = 0x1F;    //fclk 0x1F = 20M/240 
    sI2C_Config.sSetting.bIntEn = 0;
    sI2C_Config.sSetting.bI2CEn = 1;

    I2C_Init(I2C0,&sI2C_Config);
}

int I2C0_Master_Read(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len)
{
    uint32_t i;
    uint8_t u8ErrorStatus;
   
    /* send start signals to bus */
    u8ErrorStatus = I2C_Start(I2C0);

    /* send device address to slave */
    u8ErrorStatus = I2C_WriteOneByte(I2C0,((uint8_t)deviceAddr<<1) | I2C_WRITE);

    /* if no error occur, received the correct ack from slave
            continue to send data to slave
        */
    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<subAddrLen;i++)
        {
            u8ErrorStatus = I2C_WriteOneByte(I2C0,pSubAddr[i]);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
     }
    
    /* send start signals to bus */
    u8ErrorStatus = I2C_RepeatStart(I2C0);

    /* send device address to slave */
    u8ErrorStatus = I2C_WriteOneByte(I2C0,((uint8_t)deviceAddr<<1) | I2C_READ);
     
        /* if no error occur, received the correct ack from slave
            continue to send data to slave
        */
    /* dummy read one byte to switch to Rx mode */
    I2C_ReadOneByte(I2C0,&pBuf[0],I2C_SEND_ACK);

    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<len-1;i++)
        {
            u8ErrorStatus = I2C_ReadOneByte(I2C0,&pBuf[i],I2C_SEND_ACK);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
        u8ErrorStatus = I2C_ReadOneByte(I2C0,&pBuf[i],I2C_SEND_NACK);
     }
     /* send stop signals to bus */
     u8ErrorStatus = I2C_Stop(I2C0); 

     //return u8ErrorStatus;   
	 return len;
}

int I2C0_Master_Write(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len)
{
    uint32_t i;
    uint8_t u8ErrorStatus;

    /* send start signals to bus */
    u8ErrorStatus = I2C_Start(I2C0);

    /* send device address to slave */
    u8ErrorStatus = I2C_WriteOneByte(I2C0,((uint8_t)deviceAddr<<1) | I2C_WRITE);

    /* if no error occur, received the correct ack from slave
            continue to send data to slave
        */
    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<subAddrLen;i++)
        {
            u8ErrorStatus = I2C_WriteOneByte(I2C0,pSubAddr[i]);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
     }
        
    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<len;i++)
        {
            u8ErrorStatus = I2C_WriteOneByte(I2C0,pBuf[i]);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
     }

     /* send stop signals to bus */
     u8ErrorStatus = I2C_Stop(I2C0);

     //return u8ErrorStatus;
   
	 return len;
}

void I2C1_User_Init(void)// E0=SDA, E1=SCL
{
    I2C_ConfigType  sI2C_Config = {0};
    
    //SIM_RemapI2C1ToPTE_0_1(); // default
    
    /* Initialize I2C module with poll mode */
    sI2C_Config.u16F = 0x1F;    //fclk = 20M/240 
    sI2C_Config.sSetting.bIntEn = 0;
    sI2C_Config.sSetting.bI2CEn = 1;

    I2C_Init(I2C1,&sI2C_Config);
}

int I2C1_Master_Read(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len)
{
    uint32_t i;
    uint8_t u8ErrorStatus;

    /* send start signals to bus */
    u8ErrorStatus = I2C_Start(I2C1);

    /* send device address to slave */
    u8ErrorStatus = I2C_WriteOneByte(I2C1,((uint8_t)deviceAddr<<1) | I2C_WRITE);

    /* if no error occur, received the correct ack from slave
            continue to send data to slave
        */
    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<subAddrLen;i++)
        {
            u8ErrorStatus = I2C_WriteOneByte(I2C1,pSubAddr[i]);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
     }

    /* send start signals to bus */
    u8ErrorStatus = I2C_RepeatStart(I2C1);;

    /* send device address to slave */
    u8ErrorStatus = I2C_WriteOneByte(I2C1,((uint8_t)deviceAddr<<1) | I2C_READ);
     
        /* if no error occur, received the correct ack from slave
            continue to send data to slave
        */
    /* dummy read one byte to switch to Rx mode */
    I2C_ReadOneByte(I2C1,&pBuf[0],I2C_SEND_ACK);

    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<len-1;i++)
        {
            u8ErrorStatus = I2C_ReadOneByte(I2C1,&pBuf[i],I2C_SEND_ACK);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
        u8ErrorStatus = I2C_ReadOneByte(I2C1,&pBuf[i],I2C_SEND_NACK);
     }
     /* send stop signals to bus */
     u8ErrorStatus = I2C_Stop(I2C1); 

     //return u8ErrorStatus;   
	 return len;
}

int I2C1_Master_Write(unsigned short deviceAddr, unsigned char* pSubAddr, int subAddrLen, unsigned char* pBuf, int len)
{
    uint32_t i;
    uint8_t u8ErrorStatus;

    /* send start signals to bus */
    u8ErrorStatus = I2C_Start(I2C1);

    /* send device address to slave */
    u8ErrorStatus = I2C_WriteOneByte(I2C1,((uint8_t)deviceAddr<<1) | I2C_WRITE);

    /* if no error occur, received the correct ack from slave
            continue to send data to slave
        */
    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<subAddrLen;i++)
        {
            u8ErrorStatus = I2C_WriteOneByte(I2C1,pSubAddr[i]);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
     }
        
    if( u8ErrorStatus == I2C_ERROR_NULL )
    {
        for(i=0;i<len;i++)
        {
            u8ErrorStatus = I2C_WriteOneByte(I2C1,pBuf[i]);
            if( u8ErrorStatus != I2C_ERROR_NULL )
            {
                return u8ErrorStatus;
            }
        }
     }

     /* send stop signals to bus */
     u8ErrorStatus = I2C_Stop(I2C1);

     //return u8ErrorStatus;
   
	 return len;
}

void InitSysCtrlports(void)
{
    LED1_Init();
    LED2_Init();
    
    STEPMOTOR_GPIO_Init();
    
    SEG04_EN_Init();
    SEG04_DIR_Init();
    SEG04_BUSY_Init();
    
    HG_C1050_IN_Init();
    HG_C1050_OUT_Init();
    
    VM_PWR_CTRL_Init();
    MO_PWR_CTRL_Init();
    
    SPI0_CS1_INIT();     // SPI_CS needs to be output driven by SW 
}

void delayms(uint16 ms) 
{
	  volatile unsigned int delayval;
	  delayval = ms * 6400; //3200
	  while(delayval--);
}

void delayus(uint16 us) 
{
	  static volatile unsigned int delayval;
	  delayval = us * 7; //4
	  while(delayval--);
}

