//******************************************************************************
//THIS PROGRAM IS PROVIDED "AS IS". TI MAKES NO WARRANTIES OR
//REPRESENTATIONS, EITHER EXPRESS, IMPLIED OR STATUTORY,
//INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
//FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR
//COMPLETENESS OF RESPONSES, RESULTS AND LACK OF NEGLIGENCE.
//TI DISCLAIMS ANY WARRANTY OF TITLE, QUIET ENJOYMENT, QUIET
//POSSESSION, AND NON-INFRINGEMENT OF ANY THIRD PARTY
//INTELLECTUAL PROPERTY RIGHTS WITH REGARD TO THE PROGRAM OR
//YOUR USE OF THE PROGRAM.
//
//IN NO EVENT SHALL TI BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
//CONSEQUENTIAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY
//THEORY OF LIABILITY AND WHETHER OR NOT TI HAS BEEN ADVISED
//OF THE POSSIBILITY OF SUCH DAMAGES, ARISING IN ANY WAY OUT
//OF THIS AGREEMENT, THE PROGRAM, OR YOUR USE OF THE PROGRAM.
//EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF
//REMOVAL OR REINSTALLATION, COMPUTER TIME, LABOR COSTS, LOSS
//OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF
//USE OR INTERRUPTION OF BUSINESS. IN NO EVENT WILL TI'S
//AGGREGATE LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF
//YOUR USE OF THE PROGRAM EXCEED FIVE HUNDRED DOLLARS
//(U.S.$500).
//
//Unless otherwise stated, the Program written and copyrighted
//by Texas Instruments is distributed as "freeware".  You may,
//only under TI's copyright in the Program, use and modify the
//Program without any charge or restriction.  You may
//distribute to third parties, provided that you transfer a
//copy of this license to the third party and the third party
//agrees to these terms by its first use of the Program. You
//must reproduce the copyright notice and any other legend of
//ownership on each copy or partial copy, of the Program.
//
//You acknowledge and agree that the Program contains
//copyrighted material, trade secrets and other TI proprietary
//information and is protected by copyright laws,
//international copyright treaties, and trade secret laws, as
//well as other intellectual property laws.  To protect TI's
//rights in the Program, you agree not to decompile, reverse
//engineer, disassemble or otherwise translate any object code
//versions of the Program to a human-readable form.  You agree
//that in no event will you alter, remove or destroy any
//copyright notice included in the Program.  TI reserves all
//rights not specifically granted under this license. Except
//as specifically provided herein, nothing in this agreement
//shall be construed as conferring by implication, estoppel,
//or otherwise, upon you, any license or other right under any
//TI patents, copyrights or trade secrets.
// 
//You may not use the Program in non-TI devices.
//
//This software has been submitted to export control regulations
//The ECCN is EAR99 
//*****************************************************************************
/**
*  @file main.h
*
*  @brief this file contains all the definitions of the functions declared in
*  main.c. It also contains the global variables used in other modules
*
*
*  @author Daniel Torres - Texas Instruments, Inc
*  @date November 2010
*  @version 1.0 Initial version
*  @note Built with CCS for MSP430 Version: 4.2.1
*/

#ifndef _MAIN_H_
#define _MAIN_H_

#ifdef __cplusplus
extern "C"
{
#endif  
  
//*****************************************************************************
/**
* @brief  Global Functions                              
*/
//*****************************************************************************
//PORT->PUE0 &= ~(1<<(GPIO_PTA1 -0));    // PTA-D, pull up
//PORT->PUE1 &= ~(1<<(GPIO_PTE1 -32));   // PTE-H 
//PORT->PUE2 &= ~(1<<(GPIO_PTI1 -64));   // PTI

//PORT->PUE0 |= (1<<(GPIO_PTA1 -0));     // PTA-D, no pull
//PORT->PUE1 |= (1<<(GPIO_PTE1 -32));    // PTE-H 
//PORT->PUE2 |= (1<<(GPIO_PTI1 -64));    // PTI

#define SPI0CS          (GPIO_PTE3-32)
#define LED1_PIN        (GPIO_PTE7-32)
#define LED2_PIN        (GPIO_PTH2-32)
#define SEG04_EN        (GPIO_PTF0-32)
#define SEG04_DIR        GPIO_PTD4
#define SEG04_BUSY      (GPIO_PTF3-32)

#define HG_C1050_IN     GPIO_PTA1
#define HG_C1050_OUT    GPIO_PTA0

#define VM_PWR_CTRL     (GPIO_PTH7-32)
#define MO_PWR_CTRL     (GPIO_PTH6-32)

#define M1_CLK_CTRL      GPIO_PTC2
#define M1_DIR_CTRL     (GPIO_PTG0-32)  
#define M1_EN_CTRL      (GPIO_PTG1-32)
#define M1_ALM           GPIO_PTD0

#define M2_CLK_CTRL      GPIO_PTC1
#define M2_DIR_CTRL     (GPIO_PTG2-32)  
#define M2_EN_CTRL      (GPIO_PTG3-32)
#define M2_ALM           GPIO_PTD1

#define M3_CLK_CTRL     GPIO_PTC0
#define M3_DIR_CTRL     GPIO_PTC6  
#define M3_EN_CTRL      GPIO_PTC7
#define M3_ALM          GPIO_PTA2

#define M1_START        (GPIO_PTF1-32)
#define M1_STOP         (GPIO_PTE4-32)
#define M2_START        GPIO_PTA6
#define M2_STOP         GPIO_PTA7
#define M3_START        (GPIO_PTF3-32)
#define M3_STOP         (GPIO_PTF2-32)

#define M_OC_FAULT      GPIO_PTI4


#define SPI0_CS1_INIT()             GPIOB->PDDR |= (1<<SPI0CS)  
#define SPI0_CS1_RESET()            GPIOB->PCOR  = (1<<SPI0CS)
#define SPI0_CS1_SET()              GPIOB->PSOR  = (1<<SPI0CS)

#define LED1_Init()				    GPIOB->PDDR |= (1<<LED1_PIN) 
#define LED1_Toggle()		        GPIOB->PTOR = (1<<LED1_PIN) 
#define LED1_On()		            GPIOB->PSOR = (1<<LED1_PIN) 
#define LED1_Off()		            GPIOB->PCOR = (1<<LED1_PIN) 

#define LED2_Init()				    GPIOB->PDDR |= (1<<LED2_PIN) 
#define LED2_Toggle()		        GPIOB->PTOR = (1<<LED2_PIN) 
#define LED2_On()		            GPIOB->PSOR = (1<<LED2_PIN) 
#define LED2_Off()		            GPIOB->PCOR = (1<<LED2_PIN) 

#define SEG04_EN_Init()				    GPIOB->PDDR |= (1<<SEG04_EN) 
#define SEG04_EN_Toggle()		        GPIOB->PTOR = (1<<SEG04_EN) 
#define SEG04_EN_On()		            GPIOB->PSOR = (1<<SEG04_EN) 
#define SEG04_EN_Off()		            GPIOB->PCOR = (1<<SEG04_EN) 
#define SEG04_DIR_Init()				GPIOA->PDDR |= (1<<SEG04_DIR) 
#define SEG04_DIR_Toggle()		        GPIOA->PTOR = (1<<SEG04_DIR) 
#define SEG04_DIR_On()		            GPIOA->PSOR = (1<<SEG04_DIR) 
#define SEG04_DIR_Off()		            GPIOA->PCOR = (1<<SEG04_DIR) 
#define SEG04_BUSY_Init()               {GPIOB->PDDR &= ~(1<<SEG04_BUSY); GPIOB->PIDR &= ~(1<<SEG04_BUSY); PORT->PUE1 &= ~(1<<SEG04_BUSY);}    
#define SEG04_BUSY_Read()              ((GPIOB->PDIR & (1<<SEG04_BUSY)) >> SEG04_BUSY ) 

#define HG_C1050_IN_Init()				GPIOA->PDDR |= (1<<HG_C1050_IN) 
#define HG_C1050_IN_Toggle()		    GPIOA->PTOR = (1<<HG_C1050_IN) 
#define HG_C1050_IN_On()		        GPIOA->PSOR = (1<<HG_C1050_IN) 
#define HG_C1050_IN_Off()		        GPIOA->PCOR = (1<<HG_C1050_IN) 
#define HG_C1050_OUT_Init()             {GPIOA->PDDR &= ~(1<<HG_C1050_OUT); GPIOA->PIDR &= ~(1<<HG_C1050_OUT); PORT->PUE0 &= ~(1<<HG_C1050_OUT);}    
#define HG_C1050_OUT_IN()               {GPIOA->PIDR &= ~(1<<HG_C1050_OUT); }  
#define HG_C1050_OUT_Read()             ((GPIOA->PDIR & (1<<HG_C1050_OUT)) >> HG_C1050_OUT ) 

#define VM_PWR_CTRL_Init()		    GPIOB->PDDR |= (1<<VM_PWR_CTRL) 
#define VM_PWR_CTRL_Toggle()	    GPIOB->PTOR = (1<<VM_PWR_CTRL) 
#define VM_PWR_CTRL_On()		    GPIOB->PSOR = (1<<VM_PWR_CTRL) 
#define VM_PWR_CTRL_Off()		    GPIOB->PCOR = (1<<VM_PWR_CTRL) 
    
#define MO_PWR_CTRL_Init()		    GPIOB->PDDR |= (1<<MO_PWR_CTRL) 
#define MO_PWR_CTRL_Toggle()	    GPIOB->PTOR = (1<<MO_PWR_CTRL) 
#define MO_PWR_CTRL_On()		    GPIOB->PSOR = (1<<MO_PWR_CTRL) 
#define MO_PWR_CTRL_Off()		    GPIOB->PCOR = (1<<MO_PWR_CTRL) 

//���һ�źŶ���
#define M1_CLK_Init()			    GPIOA->PDDR |= (1<<M1_CLK_CTRL) 
#define M1_CLK_Toggle()		        GPIOA->PTOR = (1<<M1_CLK_CTRL) 
#define M1_CLK_On()		            GPIOA->PSOR = (1<<M1_CLK_CTRL) 
#define M1_CLK_Off()		        GPIOA->PCOR = (1<<M1_CLK_CTRL) 
#define M1_DIR_CTRL_Init()		    GPIOB->PDDR |= (1<<M1_DIR_CTRL) 
#define M1_DIR_CTRL_Toggle()	    GPIOB->PTOR = (1<<M1_DIR_CTRL) 
#define M1_DIR_CTRL_On()		    GPIOB->PSOR = (1<<M1_DIR_CTRL) 
#define M1_DIR_CTRL_Off()		    GPIOB->PCOR = (1<<M1_DIR_CTRL) 
#define M1_EN_CTRL_Init()		    GPIOB->PDDR |= (1<<M1_EN_CTRL) 
#define M1_EN_CTRL_Toggle()	        GPIOB->PTOR = (1<<M1_EN_CTRL) 
#define M1_EN_CTRL_On()		        GPIOB->PSOR = (1<<M1_EN_CTRL) 
#define M1_EN_CTRL_Off()		    GPIOB->PCOR = (1<<M1_EN_CTRL) 
#define M1_ALM_Init()               {GPIOA->PDDR &= ~(1<<M1_ALM); GPIOA->PIDR &= ~(1<<M1_ALM); PORT->PUE0 &= ~(1<<M1_ALM);}    
#define M1_ALM_Read()              ((GPIOA->PDIR & (1<<M1_ALM)) >> M1_ALM ) 

//������źŶ���
#define M2_CLK_Init()			    GPIOA->PDDR |= (1<<M2_CLK_CTRL) 
#define M2_CLK_Toggle()		        GPIOA->PTOR = (1<<M2_CLK_CTRL) 
#define M2_CLK_On()		            GPIOA->PSOR = (1<<M2_CLK_CTRL) 
#define M2_CLK_Off()		        GPIOA->PCOR = (1<<M2_CLK_CTRL) 
#define M2_DIR_CTRL_Init()		    GPIOB->PDDR |= (1<<M2_DIR_CTRL) 
#define M2_DIR_CTRL_Toggle()	    GPIOB->PTOR = (1<<M2_DIR_CTRL) 
#define M2_DIR_CTRL_On()		    GPIOB->PSOR = (1<<M2_DIR_CTRL) 
#define M2_DIR_CTRL_Off()		    GPIOB->PCOR = (1<<M2_DIR_CTRL) 
#define M2_EN_CTRL_Init()		    GPIOB->PDDR |= (1<<M2_EN_CTRL) 
#define M2_EN_CTRL_Toggle()	        GPIOB->PTOR = (1<<M2_EN_CTRL) 
#define M2_EN_CTRL_On()		        GPIOB->PSOR = (1<<M2_EN_CTRL) 
#define M2_EN_CTRL_Off()		    GPIOB->PCOR = (1<<M2_EN_CTRL) 
#define M2_ALM_Init()               {GPIOA->PDDR &= ~(1<<M2_ALM); GPIOA->PIDR &= ~(1<<M2_ALM); PORT->PUE0 &= ~(1<<M2_ALM);}    
#define M2_ALM_Read()              ((GPIOA->PDIR & (1<<M2_ALM)) >> M2_ALM ) 

//������źŶ���
#define M3_CLK_Init()			    GPIOA->PDDR |= (1<<M3_CLK_CTRL) 
#define M3_CLK_Toggle()		        GPIOA->PTOR = (1<<M3_CLK_CTRL) 
#define M3_CLK_On()		            GPIOA->PSOR = (1<<M3_CLK_CTRL) 
#define M3_CLK_Off()		        GPIOA->PCOR = (1<<M3_CLK_CTRL) 
#define M3_DIR_CTRL_Init()		    GPIOA->PDDR |= (1<<M3_DIR_CTRL) 
#define M3_DIR_CTRL_Toggle()	    GPIOA->PTOR = (1<<M3_DIR_CTRL) 
#define M3_DIR_CTRL_On()		    GPIOA->PSOR = (1<<M3_DIR_CTRL) 
#define M3_DIR_CTRL_Off()		    GPIOA->PCOR = (1<<M3_DIR_CTRL) 
#define M3_EN_CTRL_Init()		    GPIOA->PDDR |= (1<<M3_EN_CTRL) 
#define M3_EN_CTRL_Toggle()	        GPIOA->PTOR = (1<<M3_EN_CTRL) 
#define M3_EN_CTRL_On()		        GPIOA->PSOR = (1<<M3_EN_CTRL) 
#define M3_EN_CTRL_Off()		    GPIOA->PCOR = (1<<M3_EN_CTRL) 
#define M3_ALM_Init()               {GPIOA->PDDR &= ~(1<<M3_ALM); GPIOA->PIDR &= ~(1<<M3_ALM); PORT->PUE0 &= ~(1<<M3_ALM);}    
#define M3_ALM_Read()              ((GPIOA->PDIR & (1<<M3_ALM)) >> M3_ALM ) 

//��λ����
#define M1_START_Init()               {GPIOB->PDDR &= ~(1<<M1_START); GPIOB->PIDR &= ~(1<<M1_START); PORT->PUE1 &= ~(1<<M1_START);}    
#define M1_START_Read()              ((GPIOB->PDIR & (1<<M1_START)) >> M1_START ) 
#define M1_STOP_Init()               {GPIOB->PDDR &= ~(1<<M1_STOP); GPIOB->PIDR &= ~(1<<M1_STOP); PORT->PUE1 &= ~(1<<M1_STOP);}    
#define M1_STOP_Read()              ((GPIOB->PDIR & (1<<M1_STOP)) >> M1_STOP ) 

#define M2_START_Init()               {GPIOA->PDDR &= ~(1<<M2_START); GPIOA->PIDR &= ~(1<<M2_START); PORT->PUE0 &= ~(1<<M2_START);}    
#define M2_START_Read()              ((GPIOA->PDIR & (1<<M2_START)) >> M2_START ) 
#define M2_STOP_Init()               {GPIOA->PDDR &= ~(1<<M2_STOP); GPIOA->PIDR &= ~(1<<M2_STOP); PORT->PUE0 &= ~(1<<M2_STOP);}    
#define M2_STOP_Read()              ((GPIOA->PDIR & (1<<M2_STOP)) >> M2_STOP ) 

#define M3_START_Init()              {GPIOB->PDDR &= ~(1<<M3_START); GPIOB->PIDR &= ~(1<<M3_START); PORT->PUE1 &= ~(1<<M3_START);}    
#define M3_START_Read()              ((GPIOB->PDIR & (1<<M3_START)) >> M3_START ) 
#define M3_STOP_Init()               {GPIOB->PDDR &= ~(1<<M3_STOP); GPIOB->PIDR &= ~(1<<M3_STOP); PORT->PUE1 &= ~(1<<M3_STOP);}    
#define M3_STOP_Read()               ((GPIOB->PDIR & (1<<M3_STOP)) >> M3_STOP ) 

//PINSEL 0 UART0_RX and UART0_TX are mapped on PTB0 and PTB1.
//PINSEL 1 UART0_RX and UART0_TX are mapped on PTA2 and PTA3.
#define COMM_PORT               UART0               
#define COMM_UART_BITRATE       115200     

/*! define UART port # to be used */
//#define TERM_PORT               UART1       /*!< UART1 is used on KE02 freedom board */ 
//#define UART_PRINT_BITRATE      115200      /*! UART bit rate */


//*****************************************************************************
/**
* @brief  Local Functions                              
*/

#ifdef __cplusplus
}
#endif
#endif /* _MAIN_H_ */
/*------------------------ Nothing Below This Line --------------------------*/
