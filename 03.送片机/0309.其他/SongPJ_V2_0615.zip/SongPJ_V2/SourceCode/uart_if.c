#include "common.h"
#include "sysinit.h"
#include "stdlib.h"
#include "string.h" 
#include "uart.h"
#include "main.h"
#include "Common_my.h"
#include "uart_if.h"

//-------------------------------------------------------
//hardware level
uint8_t Uart0_RxBuf[UART0_MAX_RX_LEN] = {0};
char    Uart0_TxBuf[UART0_MAX_TX_LEN] = {0};   

uint8_t Uart2_RxBuf[UART2_MAX_RX_LEN] = {0};
char    Uart2_TxBuf[UART2_MAX_TX_LEN] = {0};  

//-------------------------------------------------------
uart_rx_param_t comm_rx_param = 
{
    Uart0_RxBuf,
    sizeof(Uart0_RxBuf),
    0,
};

uart_rx_param_t term_rx_param = 
{
    Uart2_RxBuf,
    sizeof(Uart2_RxBuf),
    0,
};


void Uart0_Init(void)   //uart0 B0, B1
{
    UART_ConfigType sConfig;
    
    SIM_RemapUART0ToPTB_0_1();
    
    /* Init uart0 */
    sConfig.u32SysClkHz = BUS_CLK_HZ;
    sConfig.u32Baudrate = 57600;
    UART_Init(UART0, &sConfig); 
    
    UART_EnableRxBuffFullInt(UART0);
    enable_irq(UART0_IRQn);
}

void Uart1_Init(void)   //uart1 F2, F3
{
    UART_ConfigType sConfig;
    
    SIM_RemapUART1ToPTF_2_3();
    
    /* Init uart0 */
    sConfig.u32SysClkHz = BUS_CLK_HZ;
    sConfig.u32Baudrate = COMM_UART_BITRATE;
    UART_Init(UART1, &sConfig); 
    
    UART_EnableRxBuffFullInt(UART1);
    enable_irq(UART1_IRQn);
}

void Uart0_Send_Bytes(uint8_t* pTxbuff, uint8_t length)
{
    uint8_t i;

    for(i=0;i<length;i++)
    {
		UART_PutChar(UART0, (char)pTxbuff[i]);
    }
}

/**
* @brief Function Name : USCI1RX_ISR     .                                            
* @brief description: USCI1RX_ISR interrupt service routine, this ISR is 
*                     called when a byte is receveid in the USCI-UART, It
*                     detects the SLIP packets and identify the start/end
*                     of a message.
* @param Parameters  : None                                                    
* @return Value      : none                                                    
*/
           
void UART0_RX_ISR(void)         //COMM,//UART0
{
    uint8_t read_temp = 0;

    /* check overrun flag */
    if(UART_CheckFlag(UART0,UART_FlagOR))
    {
        read_temp = UART_ReadDataReg(UART0);     
    }
    /* check receiver */
    else if(UART_IsRxBuffFull(UART0))       
    {
        read_temp = UART_ReadDataReg(UART0);

        if(comm_rx_param.rxBufLen < comm_rx_param.rxBufSize)
        {
            comm_rx_param.pRxBuf[comm_rx_param.rxBufLen++] = read_temp;
        }
    }
    /* check transmitter */
    else if(UART_IsTxBuffEmpty(UART0))
    {
//        if(gu16UART_TxBuffPos[u8Port] != gu32UART_BuffSize[u8Port])
//        {
//            /* user tx buffer not empty */
//            pWrBuff = pUART_TxBuff[u8Port];
//            UART_WriteDataReg(UART0, pWrBuff[gu16UART_TxBuffPos[u8Port]++]);     
//        }  
//        else
//        {
//			UART_DisableTxBuffEmptyInt(pUART);
//			if (UART_TxDoneCallback[u8Port])
//			{
//			    /* call back function to tell user that tx is done */
//			    UART_TxDoneCallback[u8Port]();
//			}
//        }
    }
    else
    {
        /* default interrupt */
    }
    
}

int Uart0_Receive(uint8_t* pBuf, int size)
{
	int len = 0;

	__disable_irq();

	if(comm_rx_param.rxBufLen > 0)
	{
		if(comm_rx_param.rxBufLen <= size)
		{
			len = comm_rx_param.rxBufLen;
			memcpy(pBuf, comm_rx_param.pRxBuf, len);
			comm_rx_param.rxBufLen = 0;
		}
		else
		{
			len = size;
			memcpy(pBuf, comm_rx_param.pRxBuf, len);
			Data_Shift(comm_rx_param.pRxBuf, comm_rx_param.rxBufLen, -len);
			comm_rx_param.rxBufLen -= len;
		}
	}
    
	__enable_irq();

	return len;
}

void UART2_RX_ISR(void)   
{
    uint8_t read_temp = 0;

    /* check overrun flag */
    if(UART_CheckFlag(UART2,UART_FlagOR))
    {
        read_temp = UART_ReadDataReg(UART2);     
    }
    /* check receiver */
    else if(UART_IsRxBuffFull(UART2))       
    {
        read_temp = UART_ReadDataReg(UART2);

        if(term_rx_param.rxBufLen < term_rx_param.rxBufSize)
        {
            term_rx_param.pRxBuf[term_rx_param.rxBufLen++] = read_temp;
        }
    }
    /* check transmitter */
    else if(UART_IsTxBuffEmpty(UART2))
    {
//        if(gu16UART_TxBuffPos[u8Port] != gu32UART_BuffSize[u8Port])
//        {
//            /* user tx buffer not empty */
//            pWrBuff = pUART_TxBuff[u8Port];
//            UART_WriteDataReg(UART0, pWrBuff[gu16UART_TxBuffPos[u8Port]++]);     
//        }  
//        else
//        {
//			UART_DisableTxBuffEmptyInt(pUART);
//			if (UART_TxDoneCallback[u8Port])
//			{
//			    /* call back function to tell user that tx is done */
//			    UART_TxDoneCallback[u8Port]();
//			}
//        }
    }
    else
    {
        /* default interrupt */
    }
    
}

int Uart2_Receive(uint8_t* pBuf, int size)
{
	int len = 0;

	__disable_irq();

	if(term_rx_param.rxBufLen > 0)
	{
		if(term_rx_param.rxBufLen <= size)
		{
			len = term_rx_param.rxBufLen;
			memcpy(pBuf, term_rx_param.pRxBuf, len);
			term_rx_param.rxBufLen = 0;
		}
		else
		{
			len = size;
			memcpy(pBuf, term_rx_param.pRxBuf, len);
			Data_Shift(term_rx_param.pRxBuf, term_rx_param.rxBufLen, -len);
			term_rx_param.rxBufLen -= len;
		}
	}
    
	__enable_irq();

	return len;
}

void Uart2_Send_Bytes(uint8_t* pTxbuff, uint8_t length)
{
    uint8_t i;

    for(i=0;i<length;i++)
    {
		UART_PutChar(UART2, (char)pTxbuff[i]);
    }
}

void printf_hex(uint8_t* pBuf, int len)
{
	int i;

	if(len <= 0)
	{
		return;
	}

	for(i = 0; i < len - 1; i++)
	{
		printf("%02x, ", pBuf[i]);
	}
	printf("%02x.\r\n", pBuf[i]);
}

