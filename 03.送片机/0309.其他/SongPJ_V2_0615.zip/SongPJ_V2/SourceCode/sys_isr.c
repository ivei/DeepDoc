#include "common.h"
#include "main.h"
#include "gpio.h"
#include "ADS1118.h"
#include "StepMotor.h"
#include "sys_isr.h"


volatile uint8_t     Flag_1S                = FALSE;
volatile uint8_t     Flag_5MS               = FALSE;
volatile uint8_t     Flag_10MS              = FALSE;
volatile uint32_t    Global_Timing_Counter  = 0;

#define     MAX_GLOBAL_TIMING_COUNT         ((uint32_t)(0x9A7EC800))     

/**
* @brief Function Name: RTC1SecISR   .                                              
* @brief Description  : Timer 1Sec interrupt service routine.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/ 
void RTC1SecISR(void)
{
    //Go to Timer 1Sec ExpiredT ask
    //StateMachineTaskPointer = &Timer1SecExpiredTask;
    
    Flag_1S = TRUE;
    
    // Clear TACCRx interrupt flag
    RTC->SC |= RTC_SC_RTIF_MASK;                
}

void IRQ_Interrupt_isr(void)
{
    

    IRQ->SC |=  IRQ_SC_IRQF_MASK;
}

void PIT0ch1_5ms_isr(void) // adc
{
    static uint8_t     wdt_counter          = 0;
    static uint8_t     led_counter          = 0;

    PIT->CHANNEL[1].TFLG  |= PIT_TFLG_TIF_MASK;     
    PIT->CHANNEL[1].TCTRL &= ~PIT_TCTRL_TIE_MASK;

    Flag_5MS = TRUE;    
    Read_Bus_Curr_Volt(); 
    HAL_GPIO_EXTI_Callback();    
    
    led_counter++;
    if (led_counter > 25)  
    {  
        led_counter = 0;        
        LED1_Toggle();
    }
    
    if(0 == wdt_counter)
    {
        wdt_counter = 1;    //flip
    }
    else
    {
        //10ms interval reached.
        wdt_counter = 0;

        Flag_10MS = TRUE;

        if(Global_Timing_Counter == MAX_GLOBAL_TIMING_COUNT)
        {
            Global_Timing_Counter = 0U;    //round up
        }
        else
        {
            Global_Timing_Counter++;
        }

    }
    
    PIT->CHANNEL[1].TCTRL |= PIT_TCTRL_TIE_MASK;
}

void PIT0ch0_200us_isr(void) // adc
{
    static uint8_t     wdt_counter          = 0;
    static uint8_t     led_counter          = 0;

    PIT->CHANNEL[0].TFLG  |= PIT_TFLG_TIF_MASK;     
    PIT->CHANNEL[0].TCTRL &= ~PIT_TCTRL_TIE_MASK;

	if (MotionStatus[AXIS_Z] != STOP)
		HAL_TIM_OC_Callback(AXIS_Z);
    
    PIT->CHANNEL[0].TCTRL |= PIT_TCTRL_TIE_MASK;
}

uint32_t SysTick_GetTimeOfMs(void)
{
	return Global_Timing_Counter * sysTick_ms;
}

/**
* @brief Function Name: FTM0_PORT_ISR  .                                                
* @brief Description  : IO interrupt service.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/ 
extern void HG1050_IRQHandler(void);
void FTM0_PORT_ISR(void)    // KE02-FTM0 Capture Interrupt
{
    FTM0->CONTROLS[0].CnSC &= ~(FTM_CnSC_CHF_MASK | FTM_CnSC_CHIE_MASK);
    //FTM0->CONTROLS[1].CnSC &= ~(FTM_CnSC_CHF_MASK | FTM_CnSC_CHIE_MASK);

    HG1050_IRQHandler();

    /*enable interrupt*/
    FTM0->CONTROLS[0].CnSC |= FTM_CnSC_CHIE_MASK;
    //FTM0->CONTROLS[1].CnSC |= FTM_CnSC_CHIE_MASK;
}

/**
* @brief Function Name: FTM2_PORT_ISR  .                                                
* @brief Description  : IO interrupt service.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/ 
extern uint16_t period[];
extern void HAL_TIM_OC_Callback(uint8_t Axis);
void FTM2_PORT_ISR(void) // KE02-FTM2 Compare Interrupt
{
	if (((FTM2->CONTROLS[0].CnSC & FTM_CnSC_CHF_MASK)>>FTM_CnSC_CHF_SHIFT) == 1)  /* If the CHF of the channel is equal to 0 */
	{
        FTM2->CONTROLS[0].CnSC &= ~FTM_CnSC_CHF_MASK;
		
		if (MotionStatus[AXIS_Y] != STOP)
			HAL_TIM_OC_Callback(AXIS_Y);		
	}
}

void FTM1_PORT_ISR(void) // KE02-FTM1 Compare Interrupt
{
	if (((FTM1->CONTROLS[0].CnSC & FTM_CnSC_CHF_MASK)>>FTM_CnSC_CHF_SHIFT) == 1)  /* If the CHF of the channel is equal to 0 */
	{
		FTM1->CONTROLS[0].CnSC &= ~FTM_CnSC_CHF_MASK;
		
		if (MotionStatus[AXIS_X] != STOP)
			HAL_TIM_OC_Callback(AXIS_X);   
	}
}



//if (((FTM2->CONTROLS[2].CnSC & FTM_CnSC_CHF_MASK)>>FTM_CnSC_CHF_SHIFT) == 1)  /* If the CHF of the channel is equal to 2 */
//{
//      FTM2->CONTROLS[2].CnSC &= ~(FTM_CnSC_CHF_MASK | FTM_CnSC_CHIE_MASK);

//      M3_CLK_Toggle();
//      HAL_TIM_OC_Callback(AXIS_Z);               
//	    FTM2->CONTROLS[2].CnV = FTM2->CONTROLS[2].CnV + FTM_CnV_VAL(period[2]) ;	/* Refresh interrupt period */

//      FTM2->CONTROLS[2].CnSC |= FTM_CnSC_CHIE_MASK;
//}
