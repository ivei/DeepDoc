//******************************************************************************
//THIS PROGRAM IS PROVIDED "AS IS". TI MAKES NO WARRANTIES OR
//REPRESENTATIONS, EITHER EXPRESS, IMPLIED OR STATUTORY,
//INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
//FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR
//COMPLETENESS OF RESPONSES, RESULTS AND LACK OF NEGLIGENCE.
//TI DISCLAIMS ANY WARRANTY OF TITLE, QUIET ENJOYMENT, QUIET
//POSSESSION, AND NON-INFRINGEMENT OF ANY THIRD PARTY
//INTELLECTUAL PROPERTY RIGHTS WITH REGARD TO THE PROGRAM OR
//YOUR USE OF THE PROGRAM.
//
//IN NO EVENT SHALL TI BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
//CONSEQUENTIAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY
//THEORY OF LIABILITY AND WHETHER OR NOT TI HAS BEEN ADVISED
//OF THE POSSIBILITY OF SUCH DAMAGES, ARISING IN ANY WAY OUT
//OF THIS AGREEMENT, THE PROGRAM, OR YOUR USE OF THE PROGRAM.
//EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF
//REMOVAL OR REINSTALLATION, COMPUTER TIME, LABOR COSTS, LOSS
//OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF
//USE OR INTERRUPTION OF BUSINESS. IN NO EVENT WILL TI'S
//AGGREGATE LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF
//YOUR USE OF THE PROGRAM EXCEED FIVE HUNDRED DOLLARS
//(U.S.$500).
//
//Unless otherwise stated, the Program written and copyrighted
//by Texas Instruments is distributed as "freeware".  You may,
//only under TI's copyright in the Program, use and modify the
//Program without any charge or restriction.  You may
//distribute to third parties, provided that you transfer a
//copy of this license to the third party and the third party
//agrees to these terms by its first use of the Program. You
//must reproduce the copyright notice and any other legend of
//ownership on each copy or partial copy, of the Program.
//
//You acknowledge and agree that the Program contains
//copyrighted material, trade secrets and other TI proprietary
//information and is protected by copyright laws,
//international copyright treaties, and trade secret laws, as
//well as other intellectual property laws.  To protect TI's
//rights in the Program, you agree not to decompile, reverse
//engineer, disassemble or otherwise translate any object code
//versions of the Program to a human-readable form.  You agree
//that in no event will you alter, remove or destroy any
//copyright notice included in the Program.  TI reserves all
//rights not specifically granted under this license. Except
//as specifically provided herein, nothing in this agreement
//shall be construed as conferring by implication, estoppel,
//or otherwise, upon you, any license or other right under any
//TI patents, copyrights or trade secrets.
// 
//You may not use the Program in non-TI devices.
//
//This software has been submitted to export control regulations
//The ECCN is EAR99 
//*****************************************************************************
/**
*  @file main.c
*  @brief this file contains the state machine fuctions and the console 
*  functions, It also contains the appliaction functions and interrupt
*  service routines.
*
*
*  @author Daniel Torres - Texas Instruments, Inc
*  @date November 2010
*  @version 1.0 Initial version
*  @note Built with CCS for MSP430 Version: 4.2.1
*/
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "common.h"
#include "gpio.h"
#include "device_driver.h"
#include "ADS1118.h"
#include "uart_if.h"
#include "sys_isr.h"
#include "ADS1118.h"
#include "rotor_check.h"
#include "SCI.h"
#include "qp_move_ctrl.h"
#include "common_my.h"
#include "StepMotor.h"
#include "FM24C16.h"
#include "main.h"

//�ܽŷ��䣺
//UART0: RX PTB0, TX PTB1 (TO BCU)
//UART1: RX PTF2, TX PTF3
//UART2: RX PTD6, TX PTD7,(TEAM)
//SPI0:  SCK, MOSI, MISO, CS  PTE0, PTE1, PTE2, PTE3.(PTE4, PTE5, PTE6, PTE7)
//SPI1:  SCK, MOSI, MISO, CS  PTD0, PTD1, PTD2, PTD3.(PTD3, PTD4, PTD5)
//I2C0:  SDA PTA2, SCL PTA3
//I2C1:  SDA PTE0, SCL PTE1
//CAN0:  CAN_RX PTC6, CAN_TX PTC7
//FTM2:  CH0, CH1, CH2, CH3  PTC0, PTC1, PTC2, PTC3
//FTM0:  CH0, CH1 PTB2, PTB3
//IRQ:   PTI4
//LED:   PTG0
//ADC:
//FAULT MCU GPIO

/**
* @brief  Local Variables     .                         
*/
#define DBG_Receive(pBuf, size)         Uart2_Receive(pBuf, size)
#define DBG_Send(pTxbuff, length)       Uart2_Send_Bytes(pTxbuff, length)

#define SPJ_ReceiveBuffer(pBuf, size)   Uart0_Receive(pBuf, size)
 
int SPJ_Receive(uint8_t* pBuf, int bufSize)
{
	return SPJ_ReceiveBuffer(pBuf, bufSize);
}

/**
* @brief  Global Variables .                             
*/

//uint16_t        sys_state;
//uint16_t        SYS_STATUS  = 0; // 0=stop, 1=start
//uint8_t         DUOJI_FLAG  = 0;

#define SPJ_RX_BUF_LEN      64
#define SPJ_TX_BUF_LEN      64
#define SPJ_RXPACKET_SIZE   64
uint8_t SPJ_RX_BUF[SPJ_RX_BUF_LEN] = {0};
uint8_t SPJ_TX_BUF[SPJ_TX_BUF_LEN];
uint8_t	SPJRxPacket[SPJ_RXPACKET_SIZE];
int     SPJ_USER_LEN = 0;
int     SPJ_USER_RX_BUF_LEN = 0;
int     rxBufLen_used;
bool    bRet;
int     packet_cmd = 0xff;

spj_subState_t      spj_subState;

int         DUOJI_STATUS = 0;       // �ڶ����ڴ򿪶����־
int         JIGUANG_STATUS = 0;     // �ڶ����ڴ򿪼��⿪�ر�־
uint8_t     MOTO_STOP_FLAG = 0;     // �������״̬��־λ����stopָ������ָʾ�����
uint8_t     SPJ_BP_STATUS = 0;      // ��¼ϵͳ��Ƭ״̬��һ��3�֣�����ȡƬ�����ڻ�Ƭ���ز�̨�в�Ƭ
uint8_t     SPJ_BP_PWRUP_STATUS = 0;
/**
* @brief Function Name: main.                                                 
* @brief  Description: this function is the main routine
* It controls the SW flow and the state machine
* It also initializes the system.
* @param none                                                   
* @return none                                                    
*/  
int main(void)
{ 
    int                     len;
	bool					bRet;    
    int						i, ii;
    int						n;
    int                     rxBufLen_used;
    static uint8_t      	dbgRxBuf[128];
	int						dbgRxBufLen = 0;
    static uint8_t          Cycle_Test_Flag = 0;
    static uint8_t          Cycle_Test_Counter = 0;
    int                     t_start;
    int                     t_stop;
    
    SPJ_COMM_ZBP_SHIFT_Head_t   SPJ_COMM_ZBP_SHIFT_Head;
    SPJ_COMM_ZBP_STATUS_Head_t  SPJ_COMM_ZBP_STATUS_Head;
    
    InitMCU();  
    
    printf("System Start.\r\n");
    
    MO_PWR_CTRL_On();//moto and seg   
    SEG04_EN_On();
    delayms(800);
		
	M1_EN_CTRL_On();   //disable moto
    M2_EN_CTRL_On();   //disable moto
    M3_EN_CTRL_On();   //disable moto

    M1_EN_CTRL_Off();   //enable moto
    M2_EN_CTRL_Off();   //enable moto
    M3_EN_CTRL_Off();   //enable moto
    
    //I2C0_User_Init(); 
    //FM24_Read_Buf(0x00, &SPJ_BP_STATUS, 1);

//    if (SPJ_BP_STATUS > 0)
//    {        
//        CUR_SPJ_STATUS.MOTO_CALIB_flag = 0;
//        SPJ_BP_PWRUP_STATUS = SPJ_BP_STATUS;
//        //���쳣��Ϣ�ϱ�
//        SPJ_Send_Command_Ack(SPJ_SUBSTATE_PWRON_INFO, CMD_FAIL, SPJ_BP_STATUS);
//    }
//    else
//    {
//		  SPJ_Send_Command_Ack(SPJ_SUBSTATE_PWRON_INFO, CMD_SUCC, SPJ_BP_STATUS);
//        CUR_SPJ_STATUS.MOTO_CALIB_flag = 0;
        STEPMOTOR_AxisHome();
//        
//        if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 1)
//        {
//            SPJ_Send_Command_Ack(SPJ_SUBSTATE_INIT, CMD_SUCC, FAIL_NONE);
//        }
//        else
//        {
//            SPJ_Send_Command_Ack(SPJ_SUBSTATE_INIT, CMD_FAIL, FAIL_NOCALIB);
//        }
//    }

    spj_subState = SPJ_SUBSTATE_IDLE;
    
    for(;;)
    {
        {
            #if 1
            // setup parameter
            len = DBG_Receive(&dbgRxBuf[dbgRxBufLen], sizeof(dbgRxBuf) - dbgRxBufLen);
            if(len > 0)
            {
                // echo
                DBG_Send(&dbgRxBuf[dbgRxBufLen], len);
                dbgRxBufLen += len;
            }
            
            rxBufLen_used = 0;
            if(dbgRxBufLen >= 5)
            {
                #define CMD_SET_X	    0
                #define CMD_SET_Y	    1
                #define CMD_SET_Z		2
                #define CMD_RESET		3
                #define CMD_TEST		4
                #define CMD_SET_DJ		5
                #define CMD_SET_JG		6
				#define CMD_SET_CHECK	7
                char* cmdName[] =
                {
                    "set x ",
                    "set y ",
                    "set z ",
                    "reset",
                    "test start",   //ѭ������
                    "set DJ ",      //��צ����
                    "set JG ",      //���⿪��
					"set check start ", //��鲣Ƭ
                };
                
                int iCmd;
                char valueStr[64];
                bool bChanged = false;

                for(iCmd = 0; iCmd < ARRAY_SIZE(cmdName); iCmd++)
                {
                    if((n = myStrStr((char*)dbgRxBuf, dbgRxBufLen, cmdName[iCmd], strlen(cmdName[iCmd]))) >= 0)
                    {
                        for(i = n + strlen(cmdName[iCmd]); i < dbgRxBufLen; i++)
                        {
                            if((dbgRxBuf[i] == '\r') || (dbgRxBuf[i] == '\n'))
                            {
                                memcpy(valueStr, &dbgRxBuf[n + strlen(cmdName[iCmd])], i - n - strlen(cmdName[iCmd]));
                                valueStr[i - n - strlen(cmdName[iCmd])] = '\0';
                                rxBufLen_used = i;
                                break;
                            }
                        }
                        if(i != dbgRxBufLen)
                        {
                            switch(iCmd)
                            {
                                case CMD_SET_X:
                                    CUR_SPJ_STATUS.x_step = atoi(valueStr);
                                    bChanged = true;
                                    printf("set x step %d.\r\n", CUR_SPJ_STATUS.x_step);
                                    break;
                                case CMD_SET_Y:
                                    CUR_SPJ_STATUS.y_step = atoi(valueStr);
                                    bChanged = true;
                                    printf("set y step %d.\r\n", CUR_SPJ_STATUS.y_step);
                                    break;
                                case CMD_SET_Z:
                                    CUR_SPJ_STATUS.z_step = atoi(valueStr);
                                    bChanged = true;
                                    printf("set z step %d.\r\n", CUR_SPJ_STATUS.z_step);
                                    break;
                                case CMD_RESET:
                                    CUR_SPJ_STATUS.MOTO_ZERO_FLAG = 1;
                                    Cycle_Test_Flag = 0;
                                    printf("set to zero.\r\n");
                                    break;
                                case CMD_TEST:
                                    Cycle_Test_Flag = 1;
                                    CUR_SPJ_STATUS.ROTOR_SELECT_CNT = 1;
                                    Cycle_Test_Counter = 1;
                                    printf("Cycle Get And Return.\r\n");
                                    break;
                                case CMD_SET_DJ:
                                    DUOJI_STATUS = atoi(valueStr);
                                    bChanged = true;
                                    printf("set DJ status %d.\r\n", DUOJI_STATUS);
                                    break;
                                case CMD_SET_JG:
                                    JIGUANG_STATUS = atoi(valueStr);
                                    bChanged = true;
                                    printf("set JG status %d.\r\n", JIGUANG_STATUS);
                                    break;
																case CMD_SET_CHECK:
                                    CUR_SPJ_STATUS.CHECK_RUN_FLAG = atoi(valueStr);
                                    bChanged = true;
                                    printf("set check start %d.\r\n", CUR_SPJ_STATUS.CHECK_RUN_FLAG);
                                    break;
                                default:
                                    break;
                            }
                            
                            if(bChanged == true)
                            {
                                
                            }
                        }
                    }
                }
            }
            
            if(rxBufLen_used > 0)
            {
                Data_Shift(dbgRxBuf, dbgRxBufLen, -rxBufLen_used);
                dbgRxBufLen -= rxBufLen_used;
            }
            if(dbgRxBufLen > sizeof(dbgRxBuf) * 3 / 4)
            {
                Data_Shift(dbgRxBuf, dbgRxBufLen, -sizeof(dbgRxBuf) / 4);
                dbgRxBufLen -= sizeof(dbgRxBuf) / 4;
            }
            #endif 
        }
//----------------------------------------------------------------------------------------------------------------
        
        SPJ_USER_LEN = SPJ_Receive(&SPJ_RX_BUF[SPJ_USER_RX_BUF_LEN], sizeof(SPJ_RX_BUF) - SPJ_USER_RX_BUF_LEN);
        if(SPJ_USER_LEN > 0)
        {
            printf("SPJ Receive %d[%d+%d]/%d byte.\r\n", SPJ_USER_RX_BUF_LEN + SPJ_USER_LEN, SPJ_USER_RX_BUF_LEN, SPJ_USER_LEN, sizeof(SPJ_RX_BUF));           
            printf_hex(&SPJ_RX_BUF[SPJ_USER_RX_BUF_LEN], SPJ_USER_LEN);
            SPJ_USER_RX_BUF_LEN += SPJ_USER_LEN;
        } 
        
        rxBufLen_used	= 0;
        bRet			= FALSE;
        if(SPJ_USER_RX_BUF_LEN > 0)
        {
            bRet = SPJ_ParsePacket(SPJ_RX_BUF, SPJ_USER_RX_BUF_LEN, &rxBufLen_used, SPJRxPacket, sizeof(SPJRxPacket), &SPJ_USER_LEN);
            //printf("USED LEN %d. Buf Len %d.\r\n",rxBufLen_used, SPJ_USER_RX_BUF_LEN);
        }

        // SPJ: Process the remaining data
        if(rxBufLen_used > 0)   //��ʹ�ù�������ɾ��������δʹ�õ�����ǰ��
        {
            Data_Shift(SPJ_RX_BUF, SPJ_USER_RX_BUF_LEN, -rxBufLen_used);
            SPJ_USER_RX_BUF_LEN -= rxBufLen_used;
        }
        if(SPJ_USER_RX_BUF_LEN > sizeof(SPJ_RX_BUF) * 3 / 4) //��ֹ��� 
        {
            Data_Shift(SPJ_RX_BUF, SPJ_USER_RX_BUF_LEN, -sizeof(SPJ_RX_BUF) / 4);
            SPJ_USER_RX_BUF_LEN -= sizeof(SPJ_RX_BUF) / 4;
        }         
        
        if ( (spj_subState != SPJ_SUBSTATE_IDLE) && (bRet == TRUE) ) // �յ�һ������æ״̬ʱ
        {
            packet_cmd = deal_packet(SPJRxPacket, SPJ_USER_LEN);
            SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_MOTO_MOVE);
            bRet			= FALSE;            
        }
        
        switch(spj_subState)
        {
            case SPJ_SUBSTATE_INIT:
                t_stop = SysTick_GetTimeOfMs();
                if ( (t_stop - t_start) > 80000)    // 80S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_INIT, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
                if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 1)
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_INIT, CMD_SUCC, FAIL_NONE);
                    SPJ_BP_PWRUP_STATUS = 0x00;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
                break;    
            case SPJ_SUBSTATE_STOP:  
                t_stop = SysTick_GetTimeOfMs();  
                if ( (t_stop - t_start) > 80000)    // 80S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_STOP, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    
                    MOTO_STOP_FLAG = 0;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                } 
                
                if (MOTO_STOP_FLAG  == 1)  
                {  
                    if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )  
                    {                        
                        SPJ_Send_Command_Ack(SPJ_SUBSTATE_STOP, CMD_SUCC, FAIL_NONE);
                        MOTO_STOP_FLAG = 0;
   
                        CUR_SPJ_STATUS.total_x_step = 0;
                        CUR_SPJ_STATUS.total_y_step = 0;   
                        CUR_SPJ_STATUS.total_z_step = 0;
                        
                        step_position[0] = 0;
                        step_position[1] = 0;
                        step_position[2] = 0;
                        
                        spj_subState = SPJ_SUBSTATE_IDLE;  
                    }
                }             
                break;                
            case SPJ_SUBSTATE_STATUS: 
                t_stop = SysTick_GetTimeOfMs(); 
                if ( (t_stop - t_start) > 200000)   // 200S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_STATUS, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
                
                if (CUR_SPJ_STATUS.rotor_check_flag == 0)
                {                   
                    SPJ_COMM_ZBP_STATUS_Head.start  = 0xEB90;
                    SPJ_COMM_ZBP_STATUS_Head.len    = 22;         // dir 2 crc 21
                    SPJ_COMM_ZBP_STATUS_Head.dir    = 0x01;
                    SPJ_COMM_ZBP_STATUS_Head.cmd    = SPJ_SUBSTATE_STATUS;
                    SPJ_COMM_ZBP_STATUS_Head.result   = 0x00;         // 0x02 �ɹ���0x01 ʧ�ܣ� 00���ɹ�
                    SPJ_COMM_ZBP_STATUS_Head.reason   = 0x00;
                    
                    SPJ_COMM_ZBP_STATUS_Head.data_status[0] = (uint16_t)Rotor_Info_dip1.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[1] = (uint16_t)Rotor_Info_dip1B.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[2] = (uint16_t)Rotor_Info_dip2.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[3] = (uint16_t)Rotor_Info_dip2B.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[4] = (uint16_t)Rotor_Info_dip3.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[5] = (uint16_t)Rotor_Info_dip3B.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[6] = (uint16_t)Rotor_Info_dip4.ROTER_STATUS ; 
                    SPJ_COMM_ZBP_STATUS_Head.data_status[7] = (uint16_t)Rotor_Info_dip4B.ROTER_STATUS ; 
                    
                    SPJ_COMM_ZBP_STATUS_Head.checksum = CRC16((uint8_t*)&SPJ_COMM_ZBP_STATUS_Head.len, SPJ_COMM_ZBP_STATUS_Head.len - 1);	 //��len��data

                    SPJ_SEND_BUF((uint8_t *)&SPJ_COMM_ZBP_STATUS_Head, SPJ_COMM_ZBP_STATUS_Head.len + 3); // +(start+len)
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
                break;
            case SPJ_SUBSTATE_GET:   
                t_stop = SysTick_GetTimeOfMs(); 
                if ( (t_stop - t_start) > 80000) //80S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_GET, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }  
                if (CUR_SPJ_STATUS.zbp_get_flag == 0) //=0��ȡƬ�ѵ�λ��=1����ʼȡƬ
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_GET, CMD_SUCC, FAIL_NONE);
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }                    
                break;                
            case SPJ_SUBSTATE_RETURN:
                t_stop = SysTick_GetTimeOfMs();   
                if ( (t_stop - t_start) > 80000) //80S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_RETURN, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                } 
                if (CUR_SPJ_STATUS.zbp_rtn_flag == 0) //=0����Ƭ�ѵ�λ��=1����ʼ��Ƭ
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_RETURN, CMD_SUCC, FAIL_NONE);
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }                  
                break;                
            case SPJ_SUBSTATE_CURRENT:
                t_stop = SysTick_GetTimeOfMs(); 
                if ( (t_stop - t_start) > 5000) //5S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_CURRENT, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
                SPJ_COMM_ZBP_SHIFT_Head.start   = 0xEB90;
                SPJ_COMM_ZBP_SHIFT_Head.len     = 0x07;     // dir 2 crc
                SPJ_COMM_ZBP_SHIFT_Head.dir     = 0x01;
                SPJ_COMM_ZBP_SHIFT_Head.cmd     = SPJ_SUBSTATE_CURRENT;
                SPJ_COMM_ZBP_SHIFT_Head.result  = 0x00;     // 0x02 �ɹ���0x01 ʧ�ܣ� 00���ɹ�
                SPJ_COMM_ZBP_SHIFT_Head.reason  = 0x00;
                SPJ_COMM_ZBP_SHIFT_Head.data    = 0x00; 
                SPJ_COMM_ZBP_SHIFT_Head.checksum = CRC16((uint8_t*)&SPJ_COMM_ZBP_SHIFT_Head.len, SPJ_COMM_ZBP_SHIFT_Head.len - 1);	 //��len��data

                SPJ_SEND_BUF((uint8_t *)&SPJ_COMM_ZBP_SHIFT_Head, SPJ_COMM_ZBP_SHIFT_Head.len + 3); // +(start+len)
                spj_subState = SPJ_SUBSTATE_IDLE;
                break;                
            case SPJ_SUBSTATE_SWITCH:
                t_stop = SysTick_GetTimeOfMs(); 
                if ( (t_stop - t_start) > 1000)     //1S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_SWITCH, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
                break;    

            case SPJ_SUBSTATE_INFO:
                t_stop = SysTick_GetTimeOfMs(); 
                if ( (t_stop - t_start) > 1000)     //1S            
                {
                    SPJ_Send_Command_Ack(SPJ_SUBSTATE_INFO, CMD_FAIL, FAIL_TIMEOUT);
                    MotionStatus[AXIS_X] = STOP;
                    MotionStatus[AXIS_Y] = STOP;
                    MotionStatus[AXIS_Z] = STOP;
                    spj_subState = SPJ_SUBSTATE_IDLE;
                }
				SPJ_Send_Command_Ack(SPJ_SUBSTATE_INFO, CMD_FAIL, CUR_SPJ_STATUS.SYS_ERR);
				spj_subState = SPJ_SUBSTATE_IDLE;
                break;                  
            case SPJ_SUBSTATE_IDLE:
            default:
                if(bRet == TRUE)    // �յ�һ����
                {                            
                    t_start = SysTick_GetTimeOfMs();  
                    
                    packet_cmd = deal_packet(SPJRxPacket, SPJ_USER_LEN);
                    switch(packet_cmd)
                    {
                        case CMD_SPJ_INIT:
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            CUR_SPJ_STATUS.MOTO_CALIB_flag = 0;
                            CUR_SPJ_STATUS.MOTO_START_CALIB_flag = 1;
                            spj_subState = SPJ_SUBSTATE_INIT;
							printf("Recv Calib CMD, start handle.\r\n");
                            break;
                        case CMD_SPJ_STOP:
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 0)
                            {
                                SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_NOCALIB);
								printf("System not calib ,handle fail.\r\n");
                            }
                            else
                            {
                                CUR_SPJ_STATUS.MOTO_ZERO_FLAG = 1;  // ϵͳ����
                                spj_subState = SPJ_SUBSTATE_STOP;
								printf("System Start to Zero.\r\n");
                            }
                            break;
                        case CMD_SPJ_STATUS: //ɨ���ز�̨
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 0)
                            {
                                SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_NOCALIB);
								printf("System not calib ,handle fail.\r\n");
                            }
                            else
                            {
                                CUR_SPJ_STATUS.CHECK_RUN_FLAG = 1;
                                step_position[0] = CUR_SPJ_STATUS.total_x_step;
                                step_position[1] = CUR_SPJ_STATUS.total_y_step;
                                step_position[2] = CUR_SPJ_STATUS.total_z_step;
                                spj_subState = SPJ_SUBSTATE_STATUS;
								printf("System start check.\r\n");
                            }
                            break;
                        case CMD_SPJ_GET: 
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 0)
                            {
                                SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_NOCALIB);
								printf("System not calib ,handle fail.\r\n");
                            }
                            else
                            {
                                if (CUR_SPJ_STATUS.zbp_in_get_flag  == 0)
                                {
                                    CUR_SPJ_STATUS.ROTOR_SELECT_CNT = SPJRxPacket[5]; // ȡƬ 
                                    printf("get glass %d.\r\n", CUR_SPJ_STATUS.ROTOR_SELECT_CNT);
                                    if (CUR_SPJ_STATUS.ROTOR_SELECT_CNT > ZaiBoPian_MAX)
                                    {
                                        SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_OVER_ZBP);
                                        spj_subState = SPJ_SUBSTATE_IDLE;
										printf("System over max glass.\r\n");
                                    }
                                    else
                                    {
                                        CUR_SPJ_STATUS.zbp_get_flag = 1; 
                                        spj_subState = SPJ_SUBSTATE_GET; 
                                    }
                                }
                                else
                                {
                                    SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_ZBT_ON); 
									printf("get fail ZBT ON.\r\n");
                                    spj_subState = SPJ_SUBSTATE_IDLE;
                                }
                            }
                            break;
                        case CMD_SPJ_RETURN:
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 0)
                            {
                                SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_NOCALIB);
								printf("System not calib ,handle fail.\r\n");
                            }
                            else
                            {
                                if (CUR_SPJ_STATUS.zbp_in_get_flag  == 1)
                                {
                                    if(SPJRxPacket[5] == 0)
                                    {                                        
                                        CUR_SPJ_STATUS.zbp_rtn_flag = 1;
                                        spj_subState = SPJ_SUBSTATE_RETURN;
										printf("return glass.\r\n");
                                    }
                                    else    //����ָ����Ƭ��
                                    {
                                        CUR_SPJ_STATUS.ROTOR_SELECT_CNT = SPJRxPacket[5];
                                        CUR_SPJ_STATUS.zbp_rtn_flag = 1;
                                        CUR_SPJ_STATUS.zbp_rtn_any_flag = 1;
                                        spj_subState = SPJ_SUBSTATE_RETURN;
										printf("return glass to %d.\r\n", CUR_SPJ_STATUS.ROTOR_SELECT_CNT);
                                    }
                                }
                                else
                                {
                                    SPJ_Send_Command_Ack(packet_cmd, CMD_FAIL, FAIL_ZBT_NONE);
									printf("ZBT have nothing.\r\n");
                                    spj_subState = SPJ_SUBSTATE_IDLE;
                                }
                            }
                            break;           
                        case CMD_SPJ_CURRENT:
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            spj_subState = SPJ_SUBSTATE_CURRENT;
                            break;                            
                        case CMD_SPJ_SWITCH	:
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            spj_subState = SPJ_SUBSTATE_SWITCH;
                            break;
                        case CMD_SPJ_INFO	:
                            SPJ_Send_Command_Ack(packet_cmd, CMD_RECV, FAIL_NONE);
                            spj_subState = SPJ_SUBSTATE_INFO;
                            break;
                        default:
                            break;
                    }
                }    
                break;
        }
        
        if (Cycle_Test_Flag == 1)
        {
            if ( (CUR_SPJ_STATUS.zbp_in_get_flag  == 0) && CUR_SPJ_STATUS.zbp_get_flag == 0)
                CUR_SPJ_STATUS.zbp_get_flag = 1; 
            
            if ( (CUR_SPJ_STATUS.zbp_in_get_flag  == 1) && (CUR_SPJ_STATUS.zbp_get_flag == 0) && (CUR_SPJ_STATUS.zbp_rtn_flag == 0) )
                CUR_SPJ_STATUS.zbp_rtn_flag = 1;
            
        }
        
        if (zbp_move_select(CUR_SPJ_STATUS.ROTOR_SELECT_CNT - 1) == 1)
        {
            if (Cycle_Test_Flag == 1)
            {
                if (Cycle_Test_Counter >= ZaiBoPian_MAX)
                {
                    Cycle_Test_Counter = 0;
                }
                
                CUR_SPJ_STATUS.ROTOR_SELECT_CNT = ++Cycle_Test_Counter;
                delayms(2000);
            }
        }
        
        if (CUR_SPJ_STATUS.CHECK_RUN_FLAG == 1)
        {
            if (Check_Rotor_Start() == 1)
                CUR_SPJ_STATUS.CHECK_RUN_FLAG++;
        }
               
        if ( (MotionStatus[AXIS_X] == STOP) && (MotionStatus[AXIS_Y] == STOP)&& (MotionStatus[AXIS_Z] == STOP) )
        {
            if ( (CUR_SPJ_STATUS.MOTO_ZERO_FLAG == 1) || (CUR_SPJ_STATUS.ROTOR_SELECT_CNT > ZaiBoPian_MAX) )
            {
                if ( CUR_SPJ_STATUS.total_z_step <= temp_z_temp ) //#define temp_z_temp   25000
                {
                    All_Moto_Go_Zero();
                    MOTO_STOP_FLAG  = 1;
                    CUR_SPJ_STATUS.MOTO_ZERO_FLAG = 0;
                }
                else
                {
                    CUR_SPJ_STATUS.z_step = temp_z_temp - CUR_SPJ_STATUS.total_z_step;
                }
            }
        }
        
        if (CUR_SPJ_STATUS.MOTO_CALIB_flag == 1)
            moto_move();
        
        if (CUR_SPJ_STATUS.MOTO_START_CALIB_flag == 1)  //MOTO_START_CALIB_flag , MOTO_CALIB_flag
        {
            STEPMOTOR_AxisHome();
            CUR_SPJ_STATUS.MOTO_START_CALIB_flag = 0;
        }
        
        if (CUR_SPJ_STATUS.SYS_ERR > 0)   // have err
        {
            //SPJ_Send_Command_Ack(SPJ_SUBSTATE_INFO, CMD_FAIL, CUR_SPJ_STATUS.SYS_ERR);
            LED2_On();
            M1_EN_CTRL_On();   //disable moto
            M2_EN_CTRL_On();   //disable moto
            M3_EN_CTRL_On();   //disable moto    
			delayms(1000);
        }
        
        if (DUOJI_STATUS ==1)
        {
            DJ_CTRL(DJ_OPEN);
            DUOJI_STATUS = 0;
        }
        
        if (DUOJI_STATUS ==2)
        {
            DJ_CTRL(DJ_CLOSE);
            DUOJI_STATUS = 0;
        }
        
        if (JIGUANG_STATUS ==1)
        {
            VM_PWR_CTRL_On();     	//HG1050 Power En
            JIGUANG_STATUS = 0;
        }
        
        if (JIGUANG_STATUS ==2)
        {
            VM_PWR_CTRL_Off();     	//HG1050 Power off
            JIGUANG_STATUS = 0;
        }
        
        if(Flag_10MS == TRUE)
        {
            Flag_10MS = FALSE;
        }
        
        if (Flag_5MS == TRUE)
        {
            Flag_5MS = FALSE;
        }
        
        if(Flag_1S == TRUE)
        {           
            Flag_1S = FALSE;     
            
            if (SPJ_BP_PWRUP_STATUS > 0)
            {
                //���쳣��Ϣ�ϱ�
                SPJ_Send_Command_Ack(SPJ_SUBSTATE_PWRON_INFO, CMD_FAIL, SPJ_BP_STATUS); // �ϵ���Ϣ�ϱ�
				printf("Power On Error Code 0x%x.\r\n", SPJ_BP_STATUS);
            }
						
			if (CUR_SPJ_STATUS.SYS_ERR > 0)   // have err
			{
				SPJ_Send_Command_Ack(SPJ_SUBSTATE_INFO, CMD_FAIL, CUR_SPJ_STATUS.SYS_ERR); //���д����ϱ�
				printf("System Error Code 0x%x.\r\n", CUR_SPJ_STATUS.SYS_ERR);
			} 
		}
		
		delayms(50);
    } 
} 

/**
* @brief  Local functions.                           
*/
