#ifndef __UART_IF_H_
#define __UART_IF_H_

//*****************************************************************************
#define UART0_MAX_RX_LEN    1024
#define UART0_MAX_TX_LEN    1024

#define UART2_MAX_RX_LEN    1024
#define UART2_MAX_TX_LEN    1024

//-------------------------------------------------------
typedef struct
{
	uint8_t*		pRxBuf;
	int				rxBufSize;
	int				rxBufLen;
} uart_rx_param_t;

extern char Uart0_TxBuf[UART0_MAX_RX_LEN];   // Holds the outgoing string  

extern void Uart0_Send_Bytes(unsigned char* pTxbuff, unsigned char length);
extern int Uart0_Receive(uint8_t* pBuf, int size);
extern void Uart0_Init(void);

extern void Uart1_Init(void);   //uart1 F2, F3

extern int Uart2_Receive(uint8_t* pBuf, int size);
extern void Uart2_Send_Bytes(uint8_t* pTxbuff, uint8_t length);
extern void printf_hex(uint8_t* pBuf, int len);

#endif
